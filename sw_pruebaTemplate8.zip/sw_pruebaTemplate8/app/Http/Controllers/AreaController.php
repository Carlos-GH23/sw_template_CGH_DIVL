<?php

namespace App\Http\Controllers;

use App\Models\Area;
use App\Http\Requests\StoreAreaRequest;
use App\Http\Requests\UpdateAreaRequest;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class AreaController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    private Area $model;
    private string $source;
    private string $routeName;
    private string $module ='area';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Catalogos/Areas/';
        $this->model = new Area();
        $this->routeName = 'area.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);

/*         $this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']);
 */    }

    public function index(Request $request): Response
    {
        {
            $request['status'] = $request->status === null ? true : $request->status;
            $records = $request->status == '0' ? $this->model->onlyTrashed() : $this->model; //Aqui falta agregar el softDeletes para ocultar las Instituciones
            $records = $records->when($request->search, function ($query, $search) {
                if ($search != '') {
                    $query->where('name', 'LIKE', '%' . $search . '%')
                        ->orWhere('status', 'LIKE', '%' . $search . '%');
                }
            });
    
            return Inertia::render("{$this->source}Index", [
                'titulo'          => 'Gestión de Areas',
                'areas'         => $records->paginate(10),
                'routeName'       => $this->routeName,
                'loadingResults'  => false,
                'search'          => $request->search ?? '',
                'status'          => (bool) $request->status,
            ]);
        }
    }

    
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'        =>  'Agregar Areas',
            'routeName'     =>  $this->routeName
        ]);
    }

    
    public function store(StoreAreaRequest $request)
    {
        Area::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'Area generada con éxito!');
    }

    
    public function show(Area $area)
    {
        abort(404);
    }

    
    public function edit(Area $area)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'        =>  'Modificar Areas',
            'routeName'     =>  $this->routeName,
            'area'          =>  $area
        ]);
    }

    
    public function update(UpdateAreaRequest $request, Area $area)
    {
        $area->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Area modificada con éxito!');
    }

    
    public function destroy(Area $area)
    {
        $area->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'Area eliminada con éxito!');
    }

    public function recover($id){
        $area = Area::withTrashed()->find($id);
        if ($area) {
            $area->restore();
            return redirect()->route("{$this->routeName}index")->with('success', 'Area recuperada con éxito!');
        }
        return redirect()->route("{$this->routeName}index")->with('error', 'Error, no se pudo recuperar el Area');
    }
}
