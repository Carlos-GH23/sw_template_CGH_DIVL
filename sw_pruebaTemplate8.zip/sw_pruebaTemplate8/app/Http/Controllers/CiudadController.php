<?php

namespace App\Http\Controllers;

use App\Models\Ciudad;
use App\Http\Requests\StoreCiudadRequest;
use App\Http\Requests\UpdateCiudadRequest;
use App\Models\Estado;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class CiudadController extends Controller
{
    
    private Ciudad $model;
    private string $source;
    private string $routeName;
    private string $module = 'ciudad';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Catalogos/Ciudades/';
        $this->model = new Ciudad();
        $this->routeName = 'ciudad.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);

/*         $this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']);
 */    }

    public function index(Request $request): Response
    {
        $ciudades = $this->model;
        $ciudades = $ciudades->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name',          'LIKE', "%$search%");
                $query->orWhere('description', 'LIKE', "%$search%");
                $query->orWhere('name_estado',  'LIKE', "%$search%");
            }
        })->paginate(10)->withQueryString();
        return Inertia::render("{$this->source}Index", [
            'titulo'          => 'Gestión de Ciudades',
            'ciudades'        => $ciudades,
            'routeName'      => $this->routeName,
            'loadingResults' => false,
            'search'         => $request->search ?? '',
            'status'         => (bool) $request->status,
        ]);
    }

    
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'        =>  'Agregar Ciudad',
            'routeName'     =>  $this->routeName,
            'estados'         => Estado::orderBy('id')->get(),
        ]);
    }

    
    public function store(StoreCiudadRequest $request): RedirectResponse
    {
        Ciudad::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'Ciudad generada con éxito!');
    }

    
    public function show(Ciudad $ciudad)
    {
        abort(404);
    }

    
    public function edit(Ciudad $ciudad)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'        =>  'Modificar la Ciudad',
            'routeName'     =>  $this->routeName,
            'estados' => Estado::orderBy('id')->get(),
            'ciudad' => $ciudad,
        ]);
    }

    
    public function update(UpdateCiudadRequest $request, Ciudad $ciudad)
    {
        $ciudad->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Ciudad modificada con éxito!');
    }

    
    public function destroy(Ciudad $ciudad)
    {
        $ciudad->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'Ciudad eliminada con éxito!');
    }
}
