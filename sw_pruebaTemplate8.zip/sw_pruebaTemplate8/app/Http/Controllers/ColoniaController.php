<?php

namespace App\Http\Controllers;

use App\Models\Colonia;
use App\Http\Requests\StoreColoniaRequest;
use App\Http\Requests\UpdateColoniaRequest;
use App\Models\Estado;
use App\Models\Municipio;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class ColoniaController extends Controller
{

    private Colonia $model;
    private string $source;
    private string $routeName;
    private string $module = 'colonia';


    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Catalogos/Colonias/';
        $this->model = new Colonia();
        $this->routeName = 'colonia.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);

/*         $this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']);
 */    }
    public function index(Request $request): Response
    {
        $colonias = $this->model;
        $colonias = $colonias->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name',          'LIKE', "%$search%");
                $query->orWhere('description', 'LIKE', "%$search%");
                $query->orWhere('municipio_id',  'LIKE', "%$search%");
            }
        })->paginate(12)->withQueryString();




        return Inertia::render("{$this->source}Index", [
            'titulo'          => 'Gestión de Colonias',
            'colonias'        => $colonias,
            'routeName'      => $this->routeName,
            'loadingResults' => false,
            'search'         => $request->search ?? '',
            'status'         => (bool) $request->status,
        ]);
    }

    
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'        =>  'Agregar Colonia',
            'routeName'     =>  $this->routeName,
            'municipios'         => Municipio::orderBy('id')->get(),
            'estados'   => Estado::orderBy('id')->get()

        ]);
    }

    
    public function store(StoreColoniaRequest $request): RedirectResponse
    {
        Colonia::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'Colonia generada con éxito!');
    }

    
    public function show(Colonia $colonia)
    {
        abort(404);
    }

    
    public function edit(Colonia $colonia)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'        =>  'Modificar la Colonia',
            'routeName'     =>  $this->routeName,
            'municipios' => Municipio::orderBy('id')->get(),
            'colonias' => $colonia,
            'estados'   => Estado::orderBy('id')->get()
        ]);
    }

    
    public function update(UpdateColoniaRequest $request, Colonia $colonia)
    {
        $colonia->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Colonia modificada con éxito!');
    }


    public function destroy(Colonia $colonia)
    {
        $colonia->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'Colonia eliminada con éxito!');
    }
}
