<?php

namespace App\Http\Controllers;

use App\Models\Departamento;
use App\Http\Requests\StoreDepartamentoRequest;
use App\Http\Requests\UpdateDepartamentoRequest;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class DepartamentoController extends Controller
{

    private Departamento $model;
    private string $source;
    private string $routeName;
    private string $module = 'departamento';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Catalogos/Departamentos/';
        $this->model = new Departamento();
        $this->routeName = 'departamento.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);

/*         $this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']);
 */    }
    
    public function index(Request $request): Response
    {
        $request['status'] = $request->status === null ? true : $request->status;
        $records = $request->status == '0' ? $this->model->onlyTrashed() : $this->model; //Aqui falta agregar el softDeletes para ocultar las Instituciones
        $records = $records->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name', 'LIKE', '%' . $search . '%')
                    ->orWhere('status', 'LIKE', '%' . $search . '%')
                    ->orWhere('name_complete', 'LIKE', '%' . $search . '%');
            }
        });

        return Inertia::render("{$this->source}Index", [
            'titulo'          => 'Gestión de Departamentos',
            'departamentos'   => $records->paginate(12),
            'routeName'       => $this->routeName,
            'loadingResults'  => false,
            'search'          => $request->search ?? '',
            'status'          => (bool) $request->status,
        ]);
    }

    
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'          => 'Agregar Departamento',
            'routeName'      => $this->routeName
        ]);
    }

    
    public function store(StoreDepartamentoRequest $request)
    {
        Departamento::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'Departamento Creado con éxito!');
    }

    
    public function show(Departamento $departamento)
    {
        abort(404);
    }

    
    public function edit(Departamento $departamento)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'          => 'Modificar Departamento',
            'routeName'      => $this->routeName,
            'departamento' => $departamento
        ]);
    }

    
    public function update(UpdateDepartamentoRequest $request, Departamento $departamento)
    {
        $departamento->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Departamento modificado con éxito!');
    }

    
    public function destroy(Departamento $departamento)
    {
        $departamento->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'El Departamento se ha eliminado con éxito');
    }

    public function recover($id){
        $departamento = Departamento::withTrashed()->find($id);
        if ($departamento) {
            $departamento->restore();
            return redirect()->route("{$this->routeName}index")->with('success', 'Departamento recuperado con éxito!');
        }
        return redirect()->route("{$this->routeName}index")->with('error', 'Error, no se pudo recuperar el Departamento');
    }
}
