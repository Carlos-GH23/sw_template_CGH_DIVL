<?php

namespace App\Http\Controllers;

use App\Models\Estado;
use App\Http\Requests\StoreEstadoRequest;
use App\Http\Requests\UpdateEstadoRequest;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class EstadoController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    private Estado $model;
    private string $source;
    private string $routeName;
    private string $module = 'estado';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Catalogos/Estados/';
        $this->model = new Estado();
        $this->routeName = 'estado.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);

/*         $this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']);
 */    }

    public function index(Request $request): Response
    {
        {
            $request['status'] = $request->status === null ? true : $request->status;
            $records = $request->status == '0' ? $this->model->onlyTrashed() : $this->model; //Aqui falta agregar el softDeletes para ocultar las Instituciones
            $records = $records->when($request->search, function ($query, $search) {
                if ($search != '') {
                    $query->where('name', 'LIKE', '%' . $search . '%');
                }
            });
    
            return Inertia::render("{$this->source}Index", [
                'titulo'          => 'Gestión de Estados',
                'estados'         => $records->paginate(12),
                'routeName'       => $this->routeName,
                'loadingResults'  => false,
                'search'          => $request->search ?? '',
                'status'          => (bool) $request->status,
            ]);
        }
    }

    
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'        =>  'Agregar Estado',
            'routeName'     =>  $this->routeName
        ]);
    }

    public function store(StoreEstadoRequest $request)
    {
        Estado::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'Estado generado con éxito!');

    }

    
    public function show(Estado $estado)
    {
        abort(404);
    }

    
    public function edit(Estado $estado)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'        =>  'Modificar el Estados',
            'routeName'     =>  $this->routeName,
            'estado'          =>  $estado
        ]);
    }

    
    public function update(UpdateEstadoRequest $request, Estado $estado)
    {
        $estado->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Estado modificado con éxito!');
    }

    
    public function destroy(Estado $estado)
    {
        $estado->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'Estado eliminado con éxito!');
    }

    public function recover($id){
        $estado = Estado::withTrashed()->find($id);
        if ($estado) {
            $estado->restore();
            return redirect()->route("{$this->routeName}index")->with('success', 'Estado recuperado con éxito!');
        }
        return redirect()->route("{$this->routeName}index")->with('error', 'Error, no se pudo recuperar el Estado');
    }
}
