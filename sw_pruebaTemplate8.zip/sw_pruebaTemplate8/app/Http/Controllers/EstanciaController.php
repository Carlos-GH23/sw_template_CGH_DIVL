<?php

namespace App\Http\Controllers;

use App\Models\Estancia;
use App\Http\Requests\StoreEstanciaRequest;
use App\Http\Requests\UpdateEstanciaRequest;
use App\Models\Area;
use App\Models\Colonia;
use App\Models\Estado;
use App\Models\Institution;
use App\Models\Municipio;
use App\Models\Proyecto;
use App\Models\Subarea;
use App\Models\TipoEstancia;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Inertia\Response;

class EstanciaController extends Controller
{

    private Estancia $model;
    private string $source;
    private string $routeName;
    private string $module = 'estancia';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Estancias/';
        $this->model = new Estancia();
        $this->routeName = 'estancia.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        //$this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        //$this->middleware("permission:{$this->module}.delete")->only(['destroy']);
    }
    
    public function index(Request $request): Response
    {
        $estancias  = $this->model;
        $estancias = $estancias->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name',          'LIKE', "%$search%");
                $query->orWhere('description', 'LIKE', "%$search%");
                $query->orWhere('estado_id',  'LIKE', "%$search%");
            }

            
        })->paginate(10);  

        $user = auth()->user();


        $estanciasQuery = Estancia::select(
            'estancias.id',
            'estancias.age as estancia_age',
            'estancias.zip_code',
            'estancias.outdoor_number',
            'estancias.interior_number',
            'estancias.phone_number',
            'estancias.gender',
            'estancias.hour',
            'estancias.schedule',
            'estancias.start_date',
            'estancias.ending_date',
            'estancias.degree',
            'estancias.state',
            'estancias.phone_number_institution',
            'estancias.municipality',
            'estancias.level',
            'estancias.rectors_name',
            'estancias.registration_number',
            'estancias.semester',
            'estancias.career',
            'estancias.speciality',
            'users.id as user_id',
            'users.name as user_name',
            'users.curp as user_curp',
            'users.email as user_email',
            'estados.id as estado_id',
            'estados.name as estado_name',
            'municipios.id as municipio_id',
            'municipios.name as municipio_name',
            'colonias.id as colonia_id',
            'colonias.name as colonia_name',
            'colonias.codigo_postal as colonias_codigo_postal',
            'tipo_estancias.id as tipo_estancia_id',
            'tipo_estancias.name as tipo_estancia_name',
            'tipo_estancias.status as tipo_estancia_status',
            'areas.id as area_id',
            'areas.name as area_name',
            'subareas.id as subarea_id',
            'subareas.name as subarea_name',
            'proyectos.id as proyecto_id',
            'proyectos.name as proyecto_name',
            'proyectos.description as proyecto_description',
            'proyectos.objective as proyecto_objective',
            'proyectos.key_word as proyecto_key_word',
            'proyectos.user_id as proyecto_user_id',
            'proyecto_users.name as proyecto_user_name',
            'proyecto_users.curp as proyecto_user_curp',
            'departamentos.id as departamento_id',
            'departamentos.name as departamento_name',
            'institutions.id as institutions_id',
            'institutions.name as institutions_name',
            'institutions.status as institutions_status',
            'institutions.name_complete as institutions_name_complete',

        )   
        ->join('users', 'estancias.user_id', '=', 'users.id')
        ->join('colonias', 'estancias.colonia_id', '=', 'colonias.id')
        ->join('municipios', 'colonias.municipio_id', '=', 'municipios.id')
        ->join('estados', 'municipios.estado_id', '=', 'estados.id')
        ->join('tipo_estancias', 'estancias.tipo_estancia_id', '=', 'tipo_estancias.id')
        ->join('proyectos', 'estancias.proyecto_id', '=', 'proyectos.id')
        ->join('users as proyecto_users', 'proyectos.user_id', '=', 'proyecto_users.id')
        ->join('subareas', 'proyectos.subarea_id', '=', 'subareas.id')
        ->join('areas', 'subareas.area_id', '=', 'areas.id')
        ->join('departamentos', 'proyectos.departamento_id', '=', 'departamentos.id')
        ->join('institutions', 'estancias.institution_id', '=', 'institutions.id')
        ->where('estancias.user_id', $user->id)
        ->paginate(10);


            return Inertia::render("{$this->source}Index", [
                'titulo'            =>  'Gestion de Registro de Estadias',
                'estancias'         =>  $estanciasQuery,
                'routeName'         =>  $this->routeName,
                'loadingResults'    => false,
                'search'            =>  $request->search ?? '',
                'status'            =>  (bool) $request->status,
            ]);
    }


    
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
        'titulo'        => 'Registrar Mi Estadia en CENIDET',
        'routeName'     => $this->routeName,
        'institutions'      => Institution::orderBy('id')->get(),
        'users'         => User::orderBy('id')->get(),
        'proyectos' => Proyecto::orderBy('id')->get(),
        'areas'         => Area::orderBy('id')->get(),
        'subareas'  =>  Subarea::orderBy('id')->get(),
        'estados'  =>  Estado::orderBy('id')->get(),
        'municipios'  =>  Municipio::orderBy('id')->get(),
        'colonias'  =>  Colonia::orderBy('id')->get(),
        'tipo_estancias'  =>  TipoEstancia::orderBy('id')->get(),
        'currentUser'   => auth()->user(), // Añadir el usuario actual
        

        
        ]);
    }

    
    public function store(StoreEstanciaRequest $request)
    {
        $estancia = new Estancia($request->validated());
        $estancia->user_id = Auth::id(); // Asociar el usuario autenticado
        $estancia->save();

        return redirect()->route("{$this->routeName}index")->with('success', 'Registro generado con éxito!');
    }

    
    public function show(Estancia $estancia)
    {
        abort(404);
    }

    
    public function edit(Estancia $estancia)
    {
        
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateEstanciaRequest $request, Estancia $estancia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Estancia $estancia)
    {
        //
    }
}
