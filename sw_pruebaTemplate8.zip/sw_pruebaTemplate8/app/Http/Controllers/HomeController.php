<?php

namespace App\Http\Controllers;

use App\Models\Modulo;
use App\Models\User;
use Inertia\Inertia;

class HomeController extends Controller
{
    public function index(){
        return Inertia::render('HomeView', [
            'users' => User::count(),
            'modulos' => Modulo::count(),
        ]);
    }
}