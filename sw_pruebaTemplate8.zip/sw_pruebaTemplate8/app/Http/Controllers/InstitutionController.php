<?php

namespace App\Http\Controllers;

use App\Models\Institution;
use App\Http\Requests\StoreInstitutionRequest;
use App\Http\Requests\UpdateInstitutionRequest;
use Inertia\Inertia;
use Illuminate\Http\Request;
use Inertia\Response;

class InstitutionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    private Institution $model;
    private string $source;
    private string $routeName;
    private string $module = 'institucion';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Catalogos/Instituciones/';
        $this->model = new Institution();
        $this->routeName = 'institucion.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);

/*         $this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']);
 */    }

    public function index(Request $request): Response
    {
        $request['status'] = $request->status === null ? true : $request->status;
        $records = $request->status == '0' ? $this->model->onlyTrashed() : $this->model; //Aqui falta agregar el softDeletes para ocultar las Instituciones
        $records = $records->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name', 'LIKE', '%' . $search . '%')
                    ->orWhere('status', 'LIKE', '%' . $search . '%')
                    ->orWhere('name_complete', 'LIKE', '%' . $search . '%');
            }
        });

        return Inertia::render("{$this->source}Index", [
            'titulo'          => 'Gestión de instituciones',
            'institutions'         => $records->paginate(12),
            'routeName'       => $this->routeName,
            'loadingResults'  => false,
            'search'          => $request->search ?? '',
            'status'          => (bool) $request->status,
        ]);
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'          => 'Agregar institución',
            'routeName'      => $this->routeName
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreInstitutionRequest $request)
    {
        Institution::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'Institución generado con éxito!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Institution $institution)
    {
        abort(404);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Institution $institucion)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'          => 'Modificar institución',
            'routeName'      => $this->routeName,
            'institution' => $institucion
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateInstitutionRequest $request, Institution $institucion)
    {
        $institucion->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Institución modificada con éxito!');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Institution $institucion)
    {
        $institucion->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'La institución se a eliminado con éxito');
    }

    public function recover($id){
        $institucion = Institution::withTrashed()->find($id);
        if ($institucion) {
            $institucion->restore();
            return redirect()->route("{$this->routeName}index")->with('success', 'Institución recuperado con éxito!');
        }
        return redirect()->route("{$this->routeName}index")->with('error', 'Error, no se pudo recuperar el Institución');
    }
}
