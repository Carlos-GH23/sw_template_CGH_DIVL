<?php

namespace App\Http\Controllers;

use App\Models\Municipio;
use App\Http\Requests\StoreMunicipioRequest;
use App\Http\Requests\UpdateMunicipioRequest;
use App\Models\Estado;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class MunicipioController extends Controller
{
    
    private Municipio $model;
    private string $source;
    private string $routeName;
    private string $module = 'municipio';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Catalogos/Municipios/';
        $this->model = new Municipio();
        $this->routeName = 'municipio.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);

/*         $this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']);
 */    }

    public function index(Request $request): Response
    {
        $municipios = $this->model;
        $municipios = $municipios->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name',          'LIKE', "%$search%");
                $query->orWhere('description', 'LIKE', "%$search%");
                $query->orWhere('estado_id',  'LIKE', "%$search%");
            }
        })->paginate(12)->withQueryString();




        return Inertia::render("{$this->source}Index", [
            'titulo'          => 'Gestión de Municipios',
            'municipios'        => $municipios,
            'routeName'      => $this->routeName,
            'loadingResults' => false,
            'search'         => $request->search ?? '',
            'status'         => (bool) $request->status,
        ]);    
    }

    
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'        =>  'Agregar Municipios',
            'routeName'     =>  $this->routeName,
            'estados'         => Estado::orderBy('id')->get(),
        ]);
    }

    
    public function store(StoreMunicipioRequest $request)
    {
        Municipio::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'Municipio generado con éxito!');
    }

    
    public function show(Municipio $municipio)
    {
        abort(404);
    }

    
    public function edit(Municipio $municipio)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'        =>  'Modificar el Municipio',
            'routeName'     =>  $this->routeName,
            'estados' => Estado::orderBy('id')->get(),
            'municipio' => $municipio,
        ]);
    }

    
    public function update(UpdateMunicipioRequest $request, Municipio $municipio)
    {
        $municipio->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Municipio modificado con éxito!');
    }

    
    public function destroy(Municipio $municipio)
    {
        $municipio->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'Municipio eliminadocon éxito!');
    }
}
