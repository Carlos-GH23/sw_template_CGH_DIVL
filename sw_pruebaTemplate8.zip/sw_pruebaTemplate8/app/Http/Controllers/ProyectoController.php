<?php

namespace App\Http\Controllers;

use App\Models\Proyecto;
use App\Http\Requests\StoreProyectoRequest;
use App\Http\Requests\UpdateProyectoRequest;
use App\Models\Area;
use App\Models\Departamento;
use App\Models\Subarea;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class ProyectoController extends Controller
{
    private Proyecto $model;
    private string $source;
    private string $routeName;
    private string $module = 'proyecto';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Proyectos/';
        $this->model = new Proyecto();
        $this->routeName = 'proyecto.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);
    }

    public function index(Request $request): Response
    {
        $proyectos  = $this->model;
        $proyectos = $proyectos->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name',          'LIKE', "%$search%");
                $query->orWhere('description', 'LIKE', "%$search%");
                $query->orWhere('estado_id',  'LIKE', "%$search%");
            }

            
        })->paginate(10);  

        $user = auth()->user();


        $proyectosQuery = Proyecto::select(
            'proyectos.id',
            'proyectos.name as proyecto_name',
            'proyectos.description',
            'proyectos.objective',
            'proyectos.key_word',
            'subareas.id as subareas_id',
            'subareas.name as subareas_name',
            'subareas.status as subareas_status',
            'areas.id as area_id',
            'areas.name as areas_name',
            'areas.status as areas_status',
            'users.id as user_id',
            'departamentos.id as departamentos_id',
            'departamentos.name as departamentos_name',
            'departamentos.status as departamentos_status',


        )

            ->join('subareas', 'proyectos.subarea_id', '=', 'subareas.id')
            ->join('areas', 'subareas.area_id', '=', 'areas.id')
            ->join('users', 'proyectos.user_id', '=', 'users.id')
            ->join('departamentos', 'proyectos.departamento_id', '=', 'departamentos.id') 
            ->where('proyectos.user_id', $user->id)
        
        ->paginate(8);


        return Inertia::render("{$this->source}Index", [
            'titulo'         => 'Gestión de Proyectos',
            'proyectos'      => $proyectosQuery,
            'routeName'      => $this->routeName,
            'loadingResults' => false,
            'search'         => $request->search ?? '',
            'status'         => (bool) $request->status,
        ]);
    }

    public function create()
{
    return Inertia::render("{$this->source}Create", [
        'titulo'        => 'Agregar Proyecto',
        'routeName'     => $this->routeName,
        'subareas'      => Subarea::orderBy('id')->get(),
        'users'         => User::orderBy('id')->get(),
        'departamentos' => Departamento::orderBy('id')->get(),
        'areas'         => Area::orderBy('id')->get(),
        'proyecto'      => null,
        'currentUser'   => auth()->user(),
        
        
    ]);
}

    public function store(StoreProyectoRequest $request)
    {
        Proyecto::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'Proyecto Creado con éxito!');
    }

    public function show(Proyecto $proyecto)
    {
        abort(404);
    }

    public function edit(Proyecto $proyecto)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'        => 'Modificar Proyecto',
            'routeName'     => $this->routeName,
            'proyecto'      => $proyecto,
            'subareas'      => Subarea::orderBy('id')->get(),
            'users'      => User::orderBy('id')->get(),
            'departamentos' => Departamento::orderBy('id')->get(),
            'areas' => Area::orderBy('id')->get(),
        ]);
    }

    public function update(UpdateProyectoRequest $request, Proyecto $proyecto)
    {


        $proyecto->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Proyecto modificado con éxito!');
    }

    public function destroy(Proyecto $proyecto)
    {
        $proyecto->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'El Proyecto se ha eliminado con éxito');
    }

    public function recover($id)
    {
        $proyecto = Proyecto::withTrashed()->find($id);
        if ($proyecto) {
            $proyecto->restore();
            return redirect()->route("{$this->routeName}index")->with('success', 'Proyecto recuperado con éxito!');
        }
        return redirect()->route("{$this->routeName}index")->with('error', 'Error, no se pudo recuperar el Proyecto');
    }
}
