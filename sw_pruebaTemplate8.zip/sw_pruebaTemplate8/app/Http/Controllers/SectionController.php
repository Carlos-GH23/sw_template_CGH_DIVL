<?php

namespace App\Http\Controllers;

use App\Models\Section;
use App\Http\Requests\StoreSectionRequest;
use App\Http\Requests\UpdateSectionRequest;
use Inertia\Inertia;
use Illuminate\Http\Request;
use Inertia\Response;

class SectionController extends Controller
{
    private Section $model;
    private string $source;
    private string $routeName;
    private string $module = 'seccion';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Seguridad/Secciones/';
        $this->model = new Section();
        $this->routeName = 'seccion.';

        /* $this->middleware("permission:{$this->module}.index")->only(['index','show']);
        $this->middleware("permission:{$this->module}.store")->only(['store','create']);
        $this->middleware("permission:{$this->module}.update")->only(['update','edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy','edit']);

        $this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']); */
    }

    public function index(Request $request): Response
    {
        $request['status'] = $request->status === null ? true : $request->status;
        $records = Section::with('subsections');
        
        $records = $request->status == '0' ? $records->onlyTrashed() : $records;

        $records = $records->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name', 'LIKE', '%' . $search . '%');
                $query->orWhere('url', 'LIKE', "%$search%");
            }
        });

        return Inertia::render("{$this->source}Index", [
            'titulo'          => 'Gestión de Secciones',
            'sections'         => $records->paginate(10),
            'routeName'       => $this->routeName,
            'loadingResults'  => false,
            'search'          => $request->search ?? '',
            'status'          => (bool) $request->status,
        ]);
    }

    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'          => 'Agregar sección',
            'sections'         => Section::orderBy('id')->get(),
            'routeName'      => $this->routeName
        ]);
    }

    public function store(StoreSectionRequest $request)
    {
        Section::create($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Sección generada con éxito!');
    }

    public function show(Section $section)
    {
        abort(404);
    }

    public function edit(Section $seccion)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'    => 'Modificar sección',
            'section'   =>  $seccion,
            'records'  =>   Section::orderBy('id')->get(),
            'routeName'=>   $this->routeName,
        ]);
    }

    public function update(UpdateSectionRequest $request, Section $seccion)
    {
        $seccion->update($request->all());
        return redirect()->route("{$this->routeName}index")->with('success', 'Sección modificada con éxito!');
    }

    public function destroy(Section $seccion)
    {
        $seccion->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'La seccion se a eliminado con éxito');
    }

    public function recover($id){
        $section = Section::withTrashed()->find($id);
        if ($section) {
            $section->restore();
            return redirect()->route("{$this->routeName}index")->with('success', 'Sección recuperado con éxito!');
        }
        return redirect()->route("{$this->routeName}index")->with('error', 'Error, no se pudo recuperar el Sección');
    }
}