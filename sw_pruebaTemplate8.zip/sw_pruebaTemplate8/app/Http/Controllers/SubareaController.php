<?php

namespace App\Http\Controllers;

use App\Models\Subarea;
use App\Http\Requests\StoreSubareaRequest;
use App\Http\Requests\UpdateSubareaRequest;
use App\Models\Area;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class SubareaController extends Controller
{
    
    private Subarea $model;
    private string $source;
    private string $routeName;
    private string $module = 'subarea';

    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Catalogos/SubAreas/';
        $this->model = new Subarea();
        $this->routeName = 'subarea.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);

/*         $this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']);
 */    }

    public function index(Request $request): Response
    {
        $subareas = $this->model;
        $subareas = $subareas->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name',          'LIKE', "%$search%");
                $query->orWhere('description', 'LIKE', "%$search%");
                $query->orWhere('area_id',  'LIKE', "%$search%");
            }
        })->paginate(10)->withQueryString();


/*         $subareasQuery = Area::with('subarea')->get();
 */

        $subareasQuery = Subarea::select(
            'subareas.id',
            'subareas.name as subarea_name',
            'subareas.status as subarea_status',
            'subareas.created_at as subarea_creacion',
            'areas.id as area_id',
            'areas.name as area_name',
            'areas.status as area_status',

        )

            ->join('areas', 'subareas.area_id', '=', 'areas.id')
            ->paginate(12);

        return Inertia::render("{$this->source}Index", [
            'titulo'          => 'Gestión de SubAreas',
            'subareas'        => $subareasQuery,
            'routeName'      => $this->routeName,
            'loadingResults' => false,
            'search'         => $request->search ?? '',
            'status'         => (bool) $request->status,
            
        ]);
    }

    
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'        =>  'Agregar SubArea',
            'routeName'     =>  $this->routeName,
            'areas'         => Area::orderBy('id')->get(),
        ]);
    }

    
    public function store(StoreSubareaRequest $request): RedirectResponse
    {
        Subarea::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'SubArea generada con éxito!');
    }

    
    public function show(Subarea $subarea)
    {
        abort(404);
    }

    
    public function edit(Subarea $subarea)
    {

      /*   $subareasQuery = Subarea::select(
            'subareas.id',
            'subareas.name as subarea_name',
            'subareas.status as subarea_status',
            'subareas.created_at as subarea_creacion',
            'areas.id as area_id',
            'areas.name as area_name',
            'areas.status as area_status',

        )

            ->join('areas', 'subareas.area_id', '=', 'areas.id')
            ->paginate(10); */

        return Inertia::render("{$this->source}Edit", [
            'titulo'        =>  'Modificar el SubArea',
            'routeName'     =>  $this->routeName,
            'areas' => Area::orderBy('id')->get(),
            'subarea' => $subarea,
            
        ]);
    }

    
    public function update(UpdateSubareaRequest $request, Subarea $subarea)
    {
        $subarea->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'SubArea modificada con éxito!');
    }

    
    public function destroy(Subarea $subarea)
    {
        $subarea->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'SubArea eliminada con éxito!');
    }

    
}
