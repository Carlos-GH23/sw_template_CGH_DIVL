<?php

namespace App\Http\Controllers;

use App\Models\TipoEstancia;
use App\Http\Requests\StoreTipoEstanciaRequest;
use App\Http\Requests\UpdateTipoEstanciaRequest;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class TipoEstanciaController extends Controller
{
    
    protected TipoEstancia $model;
    protected string $source;
    protected string $routeName;
    protected string $module = 'tipo_estancia';
    
    public function __construct()
    {
        $this->middleware('auth');
        $this->source = 'Catalogos/Estancia/';
        $this->model = new TipoEstancia();
        $this->routeName = 'tipo_estancia.';

        $this->middleware("permission:{$this->module}.index")->only(['index', 'show']);
        $this->middleware("permission:{$this->module}.store")->only(['store', 'create']);
        $this->middleware("permission:{$this->module}.update")->only(['update', 'edit']);
        $this->middleware("permission:{$this->module}.delete")->only(['destroy']);

        //$this->middleware("permission:{$this->module}.recover")->only(['recover', 'recover']);
    }

    public function index(Request $request): Response
    {
        $request['status'] = $request->status === null ? true : $request->status;
        $records = $request->status == '0' ? $this->model->onlyTrashed() : $this->model;
        $records = $records->when($request->search, function ($query, $search) {
            if ($search != '') {
                $query->where('name', 'LIKE', '%' . $search . '%')
                    ->orWhere('status', 'LIKE', '%' . $search . '%');
            }
        });

        return Inertia::render("{$this->source}Index", [
            'titulo'          => 'Gestión de Tipo de Estancias',
            'tipo_estancia'    => $records->paginate(10),
            'routeName'       => $this->routeName,
            'loadingResults'  => false,
            'search'          => $request->search ?? '',
            'status'          => (bool) $request->status,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return Inertia::render("{$this->source}Create", [
            'titulo'          => 'Agregar Tipo de Estancia',
            'routeName'      => $this->routeName
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTipoEstanciaRequest $request)
    {
        TipoEstancia::create($request->validated());

        return redirect()->route("{$this->routeName}index")->with('success', 'Tipo de Estancia generada con éxito!');
    }

    /**
     * Display the specified resource.
     */
    public function show(TipoEstancia $tipoEstancia)
    {
        abort(404);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(TipoEstancia $tipo_estancia)
    {
        return Inertia::render("{$this->source}Edit", [
            'titulo'          => 'Modificar Tipo de Estancia',
            'routeName'      => $this->routeName,
            'tipo_estancia' => $tipo_estancia
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTipoEstanciaRequest $request, TipoEstancia $tipo_estancia)
    {
        $tipo_estancia->update($request->validated());
        return redirect()->route("{$this->routeName}index")->with('success', 'Tipo de Estancia modificada con éxito!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TipoEstancia $tipo_estancia)
    {
        $tipo_estancia->delete();
        return redirect()->route("{$this->routeName}index")->with('success', 'El Tipo de Estancia se ha eliminado con éxito');
    }

    public function recover($id){
        $tipo_estancia = TipoEstancia::withTrashed()->find($id);
        if ($tipo_estancia) {
            $tipo_estancia->restore();
            return redirect()->route("{$this->routeName}index")->with('success', 'Institución recuperado con éxito!');
        }
        return redirect()->route("{$this->routeName}index")->with('error', 'Error, no se pudo recuperar el Institución');
    }
}
