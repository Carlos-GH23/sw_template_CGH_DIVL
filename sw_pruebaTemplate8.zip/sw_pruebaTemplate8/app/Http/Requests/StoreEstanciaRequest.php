<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreEstanciaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'age' => 'required|max:2',
            'zip_code' => 'required|max:5',
            'outdoor_number' => 'required|max:4',
            'interior_number' => 'required | max: 4',
            'phone_number' => 'required | max: 10',
            'gender' => 'required | max: 1',
            'hour' => 'required | max: 3',
            'schedule' => 'required',
            'start_date' => 'required',
            'ending_date' => 'required',
            'degree' => 'required',
            'state' => 'required',
            'phone_number_institution' => 'required | max: 24',
            'municipality' => 'required',
            'level' => 'required',
            'rectors_name' => 'required',
            'registration_number' => 'required | max: 20',
            'semester' => 'required | max: 2',
            'career' => 'required',
            'speciality' => 'required',
            'user_id' => 'required|unique:users,id',
            'colonia_id' => 'required|unique:colonias,id',
            'tipo_estancia_id' => 'required|unique:tipo_estancias,id',
            'institutuion_id' => 'required|unique:institutions,id',
            'proyecto_id' => 'required|unique:proyectos,id',
        ];
    }

    public function attributes(): array
    {
        return [
            'age' => 'Edad',
            'zip_code' => 'Codigo Postal',
            'outdoor_number' => 'Numero Exterior',
            'interior_number' => 'Numero Interior',
            'phone_number' => 'Numero de Telefono',
            'gender' => 'Sexo',
            'hour' => 'Horas a Cubrir',
            'schedule' => 'Horario',
            'start_date' => 'Dia de Inicio',
            'ending_date' => 'Dia de Fin',
            'degree' => 'Grado Academico del Asesor',
            'state' => 'Estado de la Institucion',
            'phone_number_institution' => 'Numero Telefonico de la Institucion',
            'municipality' => 'Municipio de la Institucion',
            'level' => 'Nivel Academico',
            'rectors_name' => 'Nombre del Rector/Director',
            'registration_number' => 'Numero de Matricula/Control',
            'semester' => 'Semestre',
            'career' => 'Carrera',
            'speciality' => 'Especialidad',
            'user_id' => 'Nombre del Profesor',
            'colonia_id' => 'Nombre de la Colonia',
            'tipo_estancia_id' => 'Tipo de Estancia',
            'institutuion_id' => 'Institucion de Procedencia',
            'proyecto_id' => 'Nombre del Proyecto',
        ];
    }
}
