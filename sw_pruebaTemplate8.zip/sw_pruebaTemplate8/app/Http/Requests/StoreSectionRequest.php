<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreSectionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name'       => 'required|max:255|unique:sections',
            'parent_id' => 'max:255',
            'url' => 'max:255',
        ];
    }

    public function attributes(): array
    {
        return [
            'name'     => 'Nombre',
            'parent_id' => 'Sección padre',
            'url'=> 'Dirección',
        ];
    }
}