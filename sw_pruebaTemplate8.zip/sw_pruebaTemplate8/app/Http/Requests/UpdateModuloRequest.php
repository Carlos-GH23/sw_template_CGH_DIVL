<?php

namespace App\Http\Requests;

use App\Models\Modulo;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateModuloRequest extends FormRequest
{
    protected string $tableName = 'module';

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'nombre' => ['required','max:255',Rule::unique(Modulo::class)->ignore($this->id)],
            'descripcion' => 'required|max:255',
            'key' => ['required','max:255',Rule::unique(Modulo::class)->ignore($this->id)],
        ];
    }

    public function attributes(): array
    {
        return [
            'nombre' => 'Nombre dek Módulo',
            'descripcion' => 'Descripción',
            'key' => 'Clave'
        ];
    }
}