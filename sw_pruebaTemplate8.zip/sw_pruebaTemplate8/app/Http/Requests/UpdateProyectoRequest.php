<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProyectoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|unique:proyectos,name,' . $this->id,
            'description' => 'required| max:65535 ',
            'objective' => 'required| max:65535',
            'key_word' => 'required',
            'subarea_id' => 'required|unique:subareas,name,' . $this->id,
            'user_id' => 'required|unique:users,name,' . $this->id,
            'departamento_id' => 'required|unique:departamentos,name,' . $this->id,
        ];
    }

    public function attributes(): array
    {
        return [
            'name' => 'Nombre',
            'description' => 'Descripcion',
            'objective' => 'Objetivo',
            'key_word' => 'Palabra clave',
            'subarea_id' => 'ID de subarea',
            'user_id' => 'ID de usuario',
            'departamento_id' => 'ID de departamento',
        ];
    }
}
