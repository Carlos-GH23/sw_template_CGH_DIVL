<?php

namespace App\Http\Requests;

use App\Models\Section;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateSectionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name'      =>  ['required','max:255',Rule::unique(Section::class)->ignore($this->id)],
            'parent_id' => 'max:255',
            'url' => 'max:255',
        ];
    }

    public function attributes(): array
    {
        return [
            'name'     => 'Nombre',
            'parent_id' => 'Sección padre',
            'url'=> 'Dirección',
        ];
    }
}