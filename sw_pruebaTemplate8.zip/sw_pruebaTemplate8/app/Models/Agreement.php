<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Agreement extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'agreements';

    protected $fillable = ['name', 'description', 'type', 'sector_id', 'institution_id','agreementDate','campus' ];

    //eloquent
    //Relacion 1 a muchos INVERSA (muchos a 1)
    

   /*  public function institution(){
        return $this->belongsTo(Institution::class)->withTrashed();
    }

    public function tipo_estancia(){
        return $this->belongsTo(TipoEstancia::class)->withTrashed();
    } */
    
}