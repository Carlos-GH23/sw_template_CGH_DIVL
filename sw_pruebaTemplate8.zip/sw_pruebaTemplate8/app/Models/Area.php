<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Area extends Model
{
    use HasFactory;
    protected $table = 'areas';

    protected $fillable = [ 'name', 'status', /* 'key' */];

     // Para las otras tablas
    // relacion 1 a n
     public function subarea(): HasMany{

        return $this->hasMany(Subarea::class);

    }
/*
    public function subareas(): HasMany
    {
        return $this->hasMany(Subarea::class);
    } */

}
