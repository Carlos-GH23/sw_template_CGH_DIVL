<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Colonia extends Model
{
    use HasFactory;

    protected $table = 'colonias';

    protected $fillable = ['name', 'codigo_postal', 'municipio_id'];

    public function colonia_estancia(): HasMany{

        return $this->hasMany(Estancia::class);

    }
}
