<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Departamento extends Model
{
    use HasFactory;

    protected $table = 'departamentos';

    protected $fillable = ['name', 'status'];

    // Para las otras tablas
    // relacion 1 a n
    public function agreement(){
        return $this->hasMany(Agreement::class)->withTrashed();
    }
}
