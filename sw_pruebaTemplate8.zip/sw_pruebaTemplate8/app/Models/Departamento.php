<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Departamento extends Model
{
    use HasFactory;

    protected $table = 'departamentos';

    protected $fillable = ['name', 'status'];

    // Para las otras tablas
    // relacion 1 a n
    public function agreement(){
        return $this->hasMany(Agreement::class)->withTrashed();
    }

    public function proyecto_departamento(): HasMany{

        return $this->hasMany(Proyecto::class);

    }
}
