<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Estancia extends Model
{
    use HasFactory;

    protected $table = 'estancias';

    protected $fillable = ['age', 'zip_code', 'outdoor_number', 'interior_number', 'phone_number', 'gender', 'hour', 'schedule', 'start_date', 'ending_date', 'degree', 'state', 'phone_number_institution', 'municipality', 'level', 'rectors_name', 'registration_number', 'semester', 'career', 'speciality', 'user_id', 'colonia_id', 'tipo_estancia_id', 'institutuion_id', 'proyecto_id'];

    
    
}
