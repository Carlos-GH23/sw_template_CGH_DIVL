<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Institution extends Model
{
    use HasFactory;
    protected $table = 'institutions';

    protected $fillable = ['name', 'status', 'name_complete'];

    // Para las otras tablas
    // relacion 1 a n
    public function agreement(){
        return $this->hasMany(Agreement::class)->withTrashed();
    }
}
