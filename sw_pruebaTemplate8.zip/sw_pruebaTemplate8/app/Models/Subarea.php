<?php

namespace App\Models;

use App\Models\Area;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Subarea extends Model
{
    use HasFactory;

    protected $table = 'subareas';

    protected $fillable = [ 'name', 'status'  /* 'name_area'  */, 'area_id'];
    
   /*  public function subarea(): BelongsTo{
        return $this->belongsTo(\App\Models\Area::class,
        'id_area'
    );
    } */

    /* public function areas()
    {
        return $this->belongsTo(Area::class, 'area_id');
    } */
}
