<?php

namespace App\Models;

use App\Models\Area;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Subarea extends Model
{
    use HasFactory;

    protected $table = 'subareas';

    protected $fillable = [ 'name', 'status'  /* 'name_area'  */, 'area_id'];
    

    public function proyecto_subarea(): HasMany{

        return $this->hasMany(Proyecto::class);

    }
   /*  public function subarea(): BelongsTo{
        return $this->belongsTo(\App\Models\Area::class,
        'area_id'
    );
    } */

    /* public function areas()
    {
        return $this->belongsTo(Area::class, 'area_id');
    } */
}
