<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class TipoEstancia extends Model
{
    use HasFactory;
    protected $table = 'tipo_estancias';

    protected $fillable = ['name', 'status'];

    /* public function agreement(){
        return $this->hasMany(Agreement::class)->withTrashed();
    } */

    public function tipo_estancia_estancia(): HasMany{

        return $this->hasMany(Estancia::class);

    }

}
