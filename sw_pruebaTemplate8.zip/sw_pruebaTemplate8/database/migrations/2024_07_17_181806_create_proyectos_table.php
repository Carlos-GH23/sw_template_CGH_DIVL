<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('proyectos', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->text('description')->nullable();
            $table->text('objective')->nullable();
            $table->string('key_word')->nullable();
            $table->foreignIdFor(
                \App\Models\Subarea::class,
                'subarea_id'
            )->constrained('subareas');
            $table->foreignIdFor(
                \App\Models\User::class,
                'user_id'
            )->constrained('users');
            $table->foreignIdFor(
                \App\Models\Departamento::class,
                'departamento_id'
            )->constrained('departamentos');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('proyectos');
    }
};
