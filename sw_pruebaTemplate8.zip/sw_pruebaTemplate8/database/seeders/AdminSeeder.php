<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Cobertura de visibilidad completa para el admin
        $adminPerfil = Role::where('name', 'Admin')->first();
        $adminPerfil->givePermissionTo(Permission::where('module_key', 'seguridad')->get());
        $adminPerfil->givePermissionTo(Permission::where('module_key', 'catalogo')->get());
        $adminPerfil->givePermissionTo(Permission::where('module_key', 'grafica')->get());
        $adminPerfil->givePermissionTo(Permission::where('module_key', 'reporte')->get());

        // Covertura de visibilidad de rol Revisor
        $perf1 = Role::where('name', 'Revisor')->first();
        $perf1->givePermissionTo(Permission::where('module_key', 'catalogo')->get());
        $perf1->givePermissionTo(Permission::where('module_key', 'seguridad')->get());
        $perf1->givePermissionTo(Permission::where('module_key', 'documentacionR')->get());
        $perf1->givePermissionTo(Permission::where('module_key', 'aceptacionR')->get());
        $perf1->givePermissionTo(Permission::where('module_key', 'liberacionR')->get());

        // Covertura de visibilidad de rol Profesor
        $perf2 = Role::where('name', 'Profesor')->first();
        $perf2->givePermissionTo(Permission::where('module_key', 'proyecto')->get());
        $perf2->givePermissionTo(Permission::where('module_key', 'postulante')->get());
        $perf2->givePermissionTo(Permission::where('module_key', 'entregableP')->get());

        // Covertura de visibilidad de rol Estudiante
        $perf3 = Role::where('name', 'Estudiante')->first();
        $perf3->givePermissionTo(Permission::where('module_key', 'proyectoE')->get());
        $perf3->givePermissionTo(Permission::where('module_key', 'entregableE')->get());
        $perf3->givePermissionTo(Permission::where('module_key', 'estancia')->get());
        $perf3->givePermissionTo(Permission::where('module_key', 'documentacionE')->get());
        $perf3->givePermissionTo(Permission::where('module_key', 'aceptacionE')->get());
        $perf3->givePermissionTo(Permission::where('module_key', 'liberacionE')->get());

    }
}
