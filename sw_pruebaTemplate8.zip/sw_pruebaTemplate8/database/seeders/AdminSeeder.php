<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Cobertura de visibilidad completa para el admin
        $adminPerfil = Role::where('name', 'Admin')->first();
        $adminPerfil->givePermissionTo(Permission::where('module_key', 'seguridad')->get());
        $adminPerfil->givePermissionTo(Permission::where('module_key', 'cat')->get());
        // $adminPerfil->givePermissionTo(Permission::where('module_key', 'educontinua')->get());
        // $adminPerfil->givePermissionTo(Permission::where('module_key', 'estecnm')->get());
        // $adminPerfil->givePermissionTo(Permission::where('module_key', 'ittecnm')->get());
        // $adminPerfil->givePermissionTo(Permission::where('module_key', 'iamtecnm')->get());

        // Covertura de visibilidad de rol correspondiente
        $perf1 = Role::where('name', 'Revisor')->first();
        $perf1->givePermissionTo(Permission::where('module_key', 'cat')->get());

        $perf2 = Role::where('name', 'Profesor')->first();
        $perf2->givePermissionTo(Permission::where('module_key', 'cat')->get());

        $perf3 = Role::where('name', 'Estudiante')->first();
        $perf3->givePermissionTo(Permission::where('module_key', 'cat')->get());

    }
}
