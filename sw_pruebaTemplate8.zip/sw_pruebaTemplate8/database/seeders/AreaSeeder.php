<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AreaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('areas')->insert([
            [
                'name' => 'Física, Matemáticas y Ciencias de la Tierra',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Biología y Química',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Medicina y Salud',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Biotecnología y Ciencias Agropecuarias',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Tecnología 4.0',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ingeniería e Industria',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias Sociales',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Interdisciplinaria (Litio, Ferroviarios, Semiconductores)',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],

        ]);
    }
}
