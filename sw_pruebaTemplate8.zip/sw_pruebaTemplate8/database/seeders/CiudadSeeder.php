<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CiudadSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('ciudades')->insert([
            [
                'name'      =>      'Cuernavaca',
                'status'    =>      '1',
                'name_estado'   =>  'Morelos',
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'name'      =>      'Cuautla',
                'status'    =>      '1',
                'name_estado'   =>  'Morelos',
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'name'      =>      'Cholula',
                'status'    =>      '1',
                'name_estado'   =>  'Puebla',
                'created_at' => date('Y-m-d H:m:s')
            ]
        ]);
    }
}
