<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ColoniaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('colonias')->insert([
            [
                'name'      =>      'Lazaro Cardenas',
                 'codigo_postal'   =>      '62080',
                 /*
                 'name_area'    =>      'Fisica Y Matematicas',
                 
                 */
                'municipio_id'      =>      '1',
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'name'      =>      'Paseo',
                 'codigo_postal'   =>      '76759',
                 /*
                 'name_area'    =>      'Fisica Y Matematicas',
                 
                 */
                'municipio_id'      =>      '1',

                'created_at' => date('Y-m-d H:m:s')
            ],
        ]);
    }
}
