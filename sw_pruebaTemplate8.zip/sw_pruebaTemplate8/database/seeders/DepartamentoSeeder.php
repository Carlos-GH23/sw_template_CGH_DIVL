<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DepartamentoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('departamentos')->insert([
            [
                'name'      => 'Recursos Humanos',
                'status'    => '1',
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'name'      => 'Centro de Computo',
                'status'    => '1',
                'created_at' => date('Y-m-d H:m:s')
            ],
        ]);
    }
}
