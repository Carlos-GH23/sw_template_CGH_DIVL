<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DepartamentoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('departamentos')->insert([
            [
                'name' => 'Subdirección Académica',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Ingeniería Electrónica',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Ingeniería Mecánica',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Ciencias Computacionales',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Desarrollo Académico e Idiomas',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Organización y Seguimiento de Estudios',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Subdirección de Planeación y Vinculación',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Oficina de Centro de Cómputo y Telecomunicaciones',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Centro de Información',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Planeación, Programación y Presupuestación',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Gestión Tecnológica y Vinculación',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Comunicación y Eventos',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Subdirección de Servicios Administrativos',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Servicios Escolares',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Recursos Materiales y Servicios',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Recursos Humanos',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Departamento de Recursos Financieros',
                'status' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],

        ]);
    }
}
