<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EstanciaSeeder extends Seeder
{

    public function run(): void
    {
        DB::table('estancias')->insert([
            [
                'age' => '1',
                'zip_code' => '62080',
                'outdoor_number' => '90',
                'interior_number' => '0',
                'phone_number' => '777123456',
                'gender' => 'M',
                'hour' => '500',
                'schedule' => '9:00 AM - 17:00 PM',
                'start_date' => '2024-07-22',
                'ending_date' => '2024-07-29',
                'degree' => 'Dr.',
                'state' => 'Morelos',
                'phone_number_institution' => '7771234212',
                'municipality' => 'Emiliano Zapata',
                'level' => 'Superior',
                'rectors_name' => 'Dr. Hugo Alejandres',
                'registration_number' => '20223TN000',
                'semester' => '6',
                'career' => 'TI',
                'speciality' => 'DSM',
                'tipo_estancia_id' => '1',
                'colonia_id' => '1',
                'proyecto_id' => '1',
                'user_id' => '5',
                'institution_id' => '1',
            ],
        ]);
    }
}
