<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class InstitutionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('institutions')->insert([
            [
                'name'      =>  'UTEZ',
                'status'    =>  '1',
                'name_complete' => 'Universidad Tecnologica Emiliano Zapata Del Estado de Morelos',
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'name'      =>  'UPEMOR',
                'status'    =>  '1',
                'name_complete' => 'Universidad Politecnica del Estado de Morelos',
                'created_at' => date('Y-m-d H:m:s')
            ],
        ]);
    }
}
