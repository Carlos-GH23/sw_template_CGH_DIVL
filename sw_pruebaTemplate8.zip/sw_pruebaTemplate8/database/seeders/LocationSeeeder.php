<?php

namespace Database\Seeders;

use App\Models\Municipality;
use App\Models\Neighborhood;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class LocationSeeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $states = [
            ['name' => 'Aguascalientes', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Baja California', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Baja California Sur', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Campeche', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Chiapas', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Chihuahua', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Coahuila', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Colima', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Ciudad de México', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Durango', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Guanajuato', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Guerrero', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Hidalgo', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Jalisco', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'México', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Michoacán', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Morelos', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Nayarit', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Nuevo León', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Oaxaca', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Puebla', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Querétaro', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Quintana Roo', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'San Luis Potosí', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Sinaloa', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Sonora', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Tabasco', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Tamaulipas', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Tlaxcala', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Veracruz', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Yucatán', 'created_at' => date('Y-m-d H:m:s')],
            ['name' => 'Zacatecas', 'created_at' => date('Y-m-d H:m:s')]
        ];

        // Insertar los estados en la base de datos
        DB::table('states')->insert($states);

        ini_set('memory_limit', '-1');
        $documento = glob('database/seeders/EXCEL/CPdescarga.xls');
        $data = Excel::toArray([], $documento[0]);

        for ($i = 0; $i < 32; $i++) {
            $skipHeader = true;
            foreach ($data[$i] as $row) {
                if ($skipHeader) {
                    $skipHeader = false;
                    continue; // Saltar la primera fila (encabezado)
                }

                // Crear o buscar el municipio
                if ($row[3] == null || $row[7] == null || $row[0] == null || $row[1] == null) {
                    break;
                }

                $municipality = Municipality::firstOrCreate([
                    'name' => $row[3],
                    'state_id' => $row[7],
                ]);

                // Crear la colonia y relacionarla con el municipio
                $neighborhood = new Neighborhood();
                $neighborhood->postal_code = $row[0];
                $neighborhood->name = $row[1];
                $neighborhood->municipality_id = $municipality->id;
                $neighborhood->save();
            }
        }
    }
}
