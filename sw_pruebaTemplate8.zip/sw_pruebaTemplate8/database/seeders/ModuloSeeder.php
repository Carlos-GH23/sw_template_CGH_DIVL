<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ModuloSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('modules')->insert([
            [
                'nombre' => 'Módulo de seguridad',
                'descripcion' => 'Módulos de seguridad',
                'key' => 'seguridad',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo Educación Continua',
                'descripcion' => 'Módulo Educación Continua',
                'key' => 'educontinua',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo Emprendimiento Social y Tecnológico',
                'descripcion' => 'Módulo Emprendimiento Social y Tecnológico',
                'key' => 'estecnm',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo Innovación Y Transferencia Tecnológica',
                'descripcion' => 'Módulo Innovación Y Transferencia Tecnológica',
                'key' => 'ittecnm',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo Intercambio Académico Y Movilidad',
                'descripcion' => 'Módulo Intercambio Académico Y Movilidad',
                'key' => 'iamtecnm',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Catálogos',
                'descripcion' => 'Módulo de Catálogos',
                'key' => 'cat',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
        ]);
    }
}
