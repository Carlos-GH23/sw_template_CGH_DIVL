<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ModuloSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('modules')->insert([
            [
                'nombre' => 'Módulo de seguridad',
                'descripcion' => 'Módulos de seguridad',
                'key' => 'seguridad',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Catálogos',
                'descripcion' => 'Módulo de Catálogos',
                'key' => 'catalogo',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Graficas',
                'descripcion' => 'Módulo de Graficas',
                'key' => 'grafica',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Reportes',
                'descripcion' => 'Módulo de Reportes',
                'key' => 'reporte',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Documentacion Revisor',
                'descripcion' => 'Módulo de Documentacion Revisor',
                'key' => 'documentacionR',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Documentacion Estudiante',
                'descripcion' => 'Módulo de Documentacion Estudiante',
                'key' => 'documentacionE',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Proyecto Profesor',
                'descripcion' => 'Módulo de Proyecto Profesor',
                'key' => 'proyectoP',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Proyecto Estudiante',
                'descripcion' => 'Módulo de Proyecto Estudiante',
                'key' => 'proyectoE',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Postulante',
                'descripcion' => 'Módulo de Postulante',
                'key' => 'postulante',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Entregable Profesor',
                'descripcion' => 'Módulo de Entregable Profesor',
                'key' => 'entregableP',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Entregable Estudiante',
                'descripcion' => 'Módulo de Entregable Estudiante',
                'key' => 'entregableE',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'nombre' => 'Módulo de Registro Estancia',
                'descripcion' => 'Módulo de Registro Estancia',
                'key' => 'registro',
                'audit_user_id' => 1,
                'created_at' => date('Y-m-d H:m:s')
            ],
        ]);
    }
}
