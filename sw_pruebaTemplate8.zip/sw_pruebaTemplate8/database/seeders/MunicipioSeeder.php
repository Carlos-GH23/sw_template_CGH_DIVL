<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MunicipioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('municipios')->insert([
            [
                'name'      =>      'Cuernavaca',
                'estado_id'   =>      '1',
                
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'name'      =>      'Jiutepec',
                 'estado_id'   =>      '1',
                 /*
                 'name_area'    =>      'Fisica Y Matematicas',
                 
                 */
                'created_at' => date('Y-m-d H:m:s')
            ],
        ]);
    }
}
