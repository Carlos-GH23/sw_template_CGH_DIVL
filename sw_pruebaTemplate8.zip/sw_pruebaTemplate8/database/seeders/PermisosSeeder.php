<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermisosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Permisos de los modulos del sistema
        Permission::create(['name' => 'modulo.seguridad', 'guard_name' => 'web', 'description' => 'Administración de Seguridad', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.educontinua', 'guard_name' => 'web', 'description' => 'Administración de Educación Continua', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'modulo.estecnm', 'guard_name' => 'web', 'description' => 'Administración de Emprendimiento Social y Tecnológico', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'modulo.ittecnm', 'guard_name' => 'web', 'description' => 'Administración de Innovación Y Transferencia Tecnológica', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'modulo.iamtecnm', 'guard_name' => 'web', 'description' => 'Administración de Intercambio Académico Y Movilidad', 'module_key' => 'iamtecnm']);
        Permission::create(['name' => 'modulo.cat', 'guard_name' => 'web', 'description' => 'Administración de Catálogos', 'module_key' => 'cat']);

        // Permisos del modulo seguridad
        Permission::create(['name' => 'modulo.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'seguridad']);

        Permission::create(['name' => 'permissions.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'permissions.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'permissions.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'permissions.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'seguridad']);

        Permission::create(['name' => 'perfiles.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'perfiles.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'perfiles.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'perfiles.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'seguridad']);

        Permission::create(['name' => 'usuarios.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'usuarios.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'usuarios.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'usuarios.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'usuarios.show', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);

        Permission::create(['name' => 'seccion.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'seccion.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'seccion.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'seccion.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'seccion.show', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);

        //PERMISOS DE ARCHIVOS
        Permission::create(['name' => 'file.index', 'guard_name' => 'web', 'description' => 'Leer Archivos', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'file.store', 'guard_name' => 'web', 'description' => 'Crear Archivos', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'file.update', 'guard_name' => 'web', 'description' => 'Actualizar Archivos', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'file.delete', 'guard_name' => 'web', 'description' => 'Eliminar Archivos', 'module_key' => 'seguridad']);
        
        // Permisos del modulo educacion continua
        Permission::create(['name' => 'conciencia.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'conciencia.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'conciencia.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'conciencia.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'conciencia.saveImage', 'guard_name' => 'web', 'description' => 'Crear Imagen', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'conciencia.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'educontinua']);

        Permission::create(['name' => 'mooc.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'mooc.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'mooc.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'mooc.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'mooc.saveImage', 'guard_name' => 'web', 'description' => 'Crear Imagen', 'module_key' => 'educontinua']);
        Permission::create(['name' => 'mooc.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'educontinua']);

        // Permisos del Emprendimiento Social y Tecnológico
        Permission::create(['name' => 'ciies.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'ciies.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'ciies.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'ciies.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'ciies.saveImage', 'guard_name' => 'web', 'description' => 'Crear Imagen', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'ciies.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'estecnm']);

        Permission::create(['name' => 'innovatecnm.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'innovatecnm.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'innovatecnm.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'innovatecnm.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'innovatecnm.saveImage', 'guard_name' => 'web', 'description' => 'Crear Imagen', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'innovatecnm.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'estecnm']);

        Permission::create(['name' => 'nodess.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'nodess.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'nodess.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'nodess.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'nodess.saveImage', 'guard_name' => 'web', 'description' => 'Crear Imagen', 'module_key' => 'estecnm']);
        Permission::create(['name' => 'nodess.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'estecnm']);

        // Permisos del modulo Innovación Y Transferencia Tecnológica
        Permission::create(['name' => 'ciia.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'ciia.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'ciia.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'ciia.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'ciia.saveImage', 'guard_name' => 'web', 'description' => 'Crear Imagen', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'ciia.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'ittecnm']);

        Permission::create(['name' => 'nodos.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'nodos.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'nodos.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'nodos.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'nodos.saveImage', 'guard_name' => 'web', 'description' => 'Crear Imagen', 'module_key' => 'ittecnm']);
        Permission::create(['name' => 'nodos.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'ittecnm']);

        // Permisos del modulo Intercambio Académico Y Movilidad
        Permission::create(['name' => 'iamtecnm.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'iamtecnm']);
        Permission::create(['name' => 'iamtecnm.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'iamtecnm']);
        Permission::create(['name' => 'iamtecnm.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'iamtecnm']);
        Permission::create(['name' => 'iamtecnm.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'iamtecnm']);
        Permission::create(['name' => 'iamtecnm.saveImage', 'guard_name' => 'web', 'description' => 'Crear Imagen', 'module_key' => 'iamtecnm']);
        Permission::create(['name' => 'iamtecnm.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'iamtecnm']);

        // Permisos del modulo Catálogos
        Permission::create(['name' => 'documento.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'documento.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'documento.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'documento.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'documento.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'cat']);

        Permission::create(['name' => 'convenio.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'convenio.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'convenio.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'convenio.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'convenio.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'viewFile', 'guard_name' => 'web', 'description' => 'Leer documento', 'module_key' => 'cat']);
        Permission::create(['name' => 'saveFile', 'guard_name' => 'web', 'description' => 'Crear documento', 'module_key' => 'cat']);

        Permission::create(['name' => 'sector.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'sector.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'sector.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'sector.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'sector.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'cat']);

        Permission::create(['name' => 'institucion.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'institucion.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'institucion.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'institucion.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'institucion.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'cat']);
        
        Permission::create(['name' => 'evento.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'evento.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'evento.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'evento.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'cat']);
        Permission::create(['name' => 'evento.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'cat']);
        
    }
}
