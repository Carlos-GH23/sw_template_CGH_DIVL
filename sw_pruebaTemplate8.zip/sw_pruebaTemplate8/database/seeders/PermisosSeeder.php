<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermisosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Permisos de los modulos del sistema
        Permission::create(['name' => 'modulo.seguridad', 'guard_name' => 'web', 'description' => 'Administración de Seguridad', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.catalogo', 'guard_name' => 'web', 'description' => 'Administración de Catálogos', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'modulo.grafica', 'guard_name' => 'web', 'description' => 'Administración de Gráficas', 'module_key' => 'grafica']);
        Permission::create(['name' => 'modulo.reporte', 'guard_name' => 'web', 'description' => 'Administración de Reportes', 'module_key' => 'reporte']);
        Permission::create(['name' => 'modulo.documentacionR', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'documentacionR']);
        Permission::create(['name' => 'modulo.documentacionE', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'documentacionE']);
        Permission::create(['name' => 'modulo.proyectoP', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'proyectoP']);
        Permission::create(['name' => 'modulo.proyectoE', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'proyectoE']);
        Permission::create(['name' => 'modulo.postulante', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'postulante']);
        Permission::create(['name' => 'modulo.entregableP', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'entregableP']);
        Permission::create(['name' => 'modulo.entregableE', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'entregableE']);
        Permission::create(['name' => 'modulo.registro', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'registro']);
        Permission::create(['name' => 'modulo.aceptacionR', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'aceptacionR']);
        Permission::create(['name' => 'modulo.aceptacionE', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'aceptacionE']);
        Permission::create(['name' => 'modulo.liberacionR', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'liberacionR']);
        Permission::create(['name' => 'modulo.liberacionE', 'guard_name' => 'web', 'description' => 'Administración de Documenacion', 'module_key' => 'liberacionE']);

        // Permisos del modulo seguridad
        Permission::create(['name' => 'modulo.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'modulo.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'seguridad']);

        Permission::create(['name' => 'permissions.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'permissions.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'permissions.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'permissions.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'seguridad']);

        Permission::create(['name' => 'perfiles.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'perfiles.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'perfiles.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'perfiles.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'seguridad']);

        Permission::create(['name' => 'usuarios.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'usuarios.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'usuarios.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'usuarios.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'seguridad']);
        Permission::create(['name' => 'usuarios.show', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'seguridad']);

        Permission::create(['name' => 'institucion.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'institucion.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'institucion.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'institucion.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'institucion.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'catalogo']);

       /*  Permission::create(['name' => 'estancia.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'estancia.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'estancia.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'estancia.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'estancia.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'catalogo']); */

        Permission::create(['name' => 'departamento.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'departamento.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'departamento.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'departamento.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'departamento.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'catalogo']);

        Permission::create(['name' => 'tipo_estancia.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'tipo_estancia.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'tipo_estancia.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'tipo_estancia.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'tipo_estancia.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'catalogo']);

        Permission::create(['name' => 'ciudad.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'ciudad.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'ciudad.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'ciudad.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'ciudad.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'catalogo']);

        Permission::create(['name' => 'area.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'area.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'area.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'area.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'catalogo']);
        Permission::create(['name' => 'area.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'catalogo']);

        
        //Permisos para Graficas de Administrador
        Permission::create(['name' => 'grafica.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'grafica']);
        Permission::create(['name' => 'grafica.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'grafica']);
        Permission::create(['name' => 'grafica.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'grafica']);
        Permission::create(['name' => 'grafica.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'grafica']);
        Permission::create(['name' => 'grafica.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'grafica']);

        //Permisos para Reportes de Administrador 
        Permission::create(['name' => 'reporte.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'reporte']);
        Permission::create(['name' => 'reporte.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'reporte']);
        Permission::create(['name' => 'reporte.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'reporte']);
        Permission::create(['name' => 'reporte.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'reporte']);
        Permission::create(['name' => 'reporte.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'reporte']);

        //Permisos para Documentacion de Revisor y Estudiantes
        Permission::create(['name' => 'documentacionR.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'documentacionR']);
        Permission::create(['name' => 'documentacionR.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'documentacionR']);
        Permission::create(['name' => 'documentacionR.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'documentacionR']);
        Permission::create(['name' => 'documentacionR.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'documentacionR']);
        Permission::create(['name' => 'documentacionR.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'documentacionR']);
        
        Permission::create(['name' => 'documentacionE.index', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'documentacionE']);

        //Permisos para Proyectos de Profesores y Estudiantes
        Permission::create(['name' => 'proyectoP.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'proyectoP']);
        Permission::create(['name' => 'proyectoP.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'proyectoP']);
        Permission::create(['name' => 'proyectoP.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'proyectoP']);
        Permission::create(['name' => 'proyectoP.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'proyectoP']);
        Permission::create(['name' => 'proyectoP.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'proyectoP']);
        
        Permission::create(['name' => 'proyectoE.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'proyectoE']);

        //Permisos para Postulantes de Profesores
        Permission::create(['name' => 'postulante.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'postulante']);
        Permission::create(['name' => 'postulante.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'postulante']);
        Permission::create(['name' => 'postulante.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'postulante']);
        Permission::create(['name' => 'postulante.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'postulante']);
        Permission::create(['name' => 'postulante.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'postulante']);

        //Permisos para Entregables de Estudiantes y Profesores
        Permission::create(['name' => 'entregableP.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'entregableP']);
        Permission::create(['name' => 'entregableP.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'entregableP']);
        Permission::create(['name' => 'entregableP.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'entregableP']);
        Permission::create(['name' => 'entregableP.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'entregableP']);
        Permission::create(['name' => 'entregableP.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'entregableP']);

        Permission::create(['name' => 'entregableE.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'entregableE']);

        //Permisos para Regsitro de Estudiantes
        Permission::create(['name' => 'registro.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'registro']);
        Permission::create(['name' => 'registro.store', 'guard_name' => 'web', 'description' => 'Crear Registros', 'module_key' => 'registro']);
        Permission::create(['name' => 'registro.update', 'guard_name' => 'web', 'description' => 'Actualizar Registros', 'module_key' => 'registro']);
        Permission::create(['name' => 'registro.delete', 'guard_name' => 'web', 'description' => 'Eliminar Registros', 'module_key' => 'registro']);
        Permission::create(['name' => 'registro.recover', 'guard_name' => 'web', 'description' => 'Recuperar Registros', 'module_key' => 'registro']);

        //Falata Agregar los Documentacion (aceptacion y liberacion)
        Permission::create(['name' => 'aceptacionR.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'aceptacionR']);
        Permission::create(['name' => 'aceptacionR.store', 'guard_name' => 'web', 'description' => 'Crear Carta Aceptacion', 'module_key' => 'aceptacionR']);
        Permission::create(['name' => 'aceptacionR.update', 'guard_name' => 'web', 'description' => 'Actualizar Carta Aceptacion', 'module_key' => 'aceptacionR']);
        Permission::create(['name' => 'aceptacionR.delete', 'guard_name' => 'web', 'description' => 'Eliminar Carta Aceptacions', 'module_key' => 'aceptacionR']);
        Permission::create(['name' => 'aceptacionR.recover', 'guard_name' => 'web', 'description' => 'Recuperar Carta Aceptacions', 'module_key' => 'aceptacionR']);
        
        Permission::create(['name' => 'aceptacionE.index', 'guard_name' => 'web', 'description' => 'Recuperar Carta Aceptacions', 'module_key' => 'aceptacionE']);

        Permission::create(['name' => 'liberacionR.index', 'guard_name' => 'web', 'description' => 'Leer Registros', 'module_key' => 'liberacionR']);
        Permission::create(['name' => 'liberacionR.store', 'guard_name' => 'web', 'description' => 'Crear Carta Liberacion', 'module_key' => 'liberacionR']);
        Permission::create(['name' => 'liberacionR.update', 'guard_name' => 'web', 'description' => 'Actualizar Carta Liberacion', 'module_key' => 'liberacionR']);
        Permission::create(['name' => 'liberacionR.delete', 'guard_name' => 'web', 'description' => 'Eliminar Carta Liberacion', 'module_key' => 'liberacionR']);
        Permission::create(['name' => 'liberacionR.recover', 'guard_name' => 'web', 'description' => 'Recuperar Carta Liberacion', 'module_key' => 'liberacionR']);

        Permission::create(['name' => 'liberacionE.index', 'guard_name' => 'web', 'description' => 'Recuperar Carta Liberacion', 'module_key' => 'liberacionE']);
    }
}
