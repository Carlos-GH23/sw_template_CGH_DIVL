<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProyectoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('proyectos')->insert([
            [
                'name'      =>      'Proyecto de Verano Cientifico',
                'description'   =>      'Hecho por Dr. Vitervo',
                'objective'   =>      'Para los mejores estudiantes',
                'key_word'   =>      'verano',
                'subarea_id'      =>      '1',
                'user_id'      =>      '1',
                'departamento_id'      =>      '1',
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'name'      =>      'Proyecto de Registro de Estadias',
                'description'   =>      'Hecho por Dr. Carsi Castrejon',
                'objective'   =>      'Para trabajar con estudiantes de estancia',
                'key_word'   =>      'registro',
                'subarea_id'      =>      '1',
                'user_id'      =>      '1',
                'departamento_id'      =>      '1',
                'created_at' => date('Y-m-d H:m:s')
            ],
        ]);
    }
}
