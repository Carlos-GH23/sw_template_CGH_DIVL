<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RenapoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('renapohistory')->insert([
            [
                'curp' => 'VIPJ020514HMSLLVA1',
                'nombres' => 'Javier',
                'apellidoPaterno' => 'Villagran',
                'apellidoMaterno' => 'Placencio',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'curp' => 'VIPJ020514HMSLLVA2',
                'nombres' => 'Javier',
                'apellidoPaterno' => 'Villagran',
                'apellidoMaterno' => 'Placencio',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'curp' => 'VIPJ020514HMSLLVA3',
                'nombres' => 'Jose Antonio',
                'apellidoPaterno' => 'Ortega',
                'apellidoMaterno' => 'Martinez',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'curp' => 'VIPJ020514HMSLLVA4',
                'nombres' => 'Chanti',
                'apellidoPaterno' => 'Heras',
                'apellidoMaterno' => 'Gomez',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'curp' => 'VIPJ020514HMSLLVA5',
                'nombres' => 'Roman',
                'apellidoPaterno' => 'Chano',
                'apellidoMaterno' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'curp' => 'VALD041020HMSZPGA3',
                'nombres' => 'Diego Ivan',
                'apellidoPaterno' => 'Vazquez',
                'apellidoMaterno' => 'Lopez',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'curp' => 'GAHC031230HVZLRRA0',
                'nombres' => 'Carlos',
                'apellidoPaterno' => 'Galan',
                'apellidoMaterno' => 'Hernandez',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'curp' => 'HECD820717MVZRSN00',
                'nombres' => 'Daniela',
                'apellidoPaterno' => 'Hernandez',
                'apellidoMaterno' => 'Castañeda',
                'created_at' => date('Y-m-d H:m:s'),
            ]
        ]);
    }
}
