<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SectionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('sections')->insert([
            // Educación Continua
            [
                'name' => 'Educación Continua',
                // 'parent_id' => '',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);

        DB::table('sections')->insert([
            [
                'name' => 'Conciencia Verde',
                'parent_id' => '1',
                'url' => '/educacion-continua#conciencia',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Mooc del TecNM',
                'parent_id' => '1',
                'url' => '/educacion-continua#mooc',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);

        DB::table('sections')->insert([
            [
                'name' => 'Lenguas Extranjeras y Maternas',
                'parent_id' => '1',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);

        DB::table('sections')->insert([
            [
                'name' => 'Lenguas Extranjeras',
                'parent_id' => '4',
                'url' => '/educacion-continua',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Lenguas Maternas',
                'parent_id' => '4',
                'url' => '/educacion-continua',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Eventos',
                'parent_id' => '4',
                'url' => '/educacion-continua',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);

        DB::table('sections')->insert([
            //Emprendimiento 8 
            [
                'name' => 'Emprendimiento Social y Tecnológico',
                // 'parent_id' => '',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);

        DB::table('sections')->insert([
            [
                'name' => 'CIIES',
                'parent_id' => '8',
                'url' => '/emprendimiento-social#ciies',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);

        DB::table('sections')->insert([
            [
                'name' => 'InnovaTecNM',
                'parent_id' => '8',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => '¿Qué Es?',
                'parent_id' => '10',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Eventos Simultáneos',
                'parent_id' => '10',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Etapa Local',
                'parent_id' => '10',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Etapa Regional',
                'parent_id' => '10',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Etapa Nacional',
                'parent_id' => '10',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Sistema',
                'parent_id' => '10',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Estadísticas',
                'parent_id' => '10',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Documentos de Referencia',
                'parent_id' => '10',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Modelo Talento Emprendedor',
                'parent_id' => '8',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => '¿Qué Es?',
                'parent_id' => '19',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => '¿Como Interpretarlo?',
                'parent_id' => '19',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Indicador',
                'parent_id' => '19',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Estadísticas',
                'parent_id' => '19',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Mooc MTE',
                'parent_id' => '19',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Despliegues',
                'parent_id' => '19',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Documentos de Referencia',
                'parent_id' => '19',
                'url' => '/emprendimiento-social',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Nodess',
                'parent_id' => '8',
                'url' => '/emprendimiento-social#nodess',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        // 28
        DB::table('sections')->insert([
            [
                'name' => 'Innovación y Trasnferencia Tecnológica',
                // 'parent_id' => '',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Catalogo de Servicios Externos TecNM',
                'parent_id' => '28',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Institutos y Centros',
                'parent_id' => '29',
                'url' => '/innovacion-transferencia',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'CIIA',
                'parent_id' => '28',
                'url' => '/innovacion-transferencia#ciia',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Nodos',
                'parent_id' => '28',
                'url' => '/innovacion-transferencia#nodos',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Protección de Autoría',
                'parent_id' => '28',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Protección Intelectual',
                'parent_id' => '33',
                'url' => '/innovacion-transferencia',
                'created_at' => date('Y-m-d H:m:s'),
            ],

            [
                'name' => 'Centros de Planteamiento',
                'parent_id' => '33',
                'url' => '/innovacion-transferencia',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Servicios de Transferencia Tecnlógica',
                'parent_id' => '33',
                'url' => '/innovacion-transferencia',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Indicadores',
                'parent_id' => '33',
                'url' => '/innovacion-transferencia',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Noticias',
                'parent_id' => '33',
                'url' => '/innovacion-transferencia',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        //39
        DB::table('sections')->insert([
            [
                'name' => 'Intercambio Académico y Movilidad',
                // 'parent_id' => '',
                'url' => '/intercambio-academico',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            //40
            [
                'name' => 'Promoción Cultural y Deportiva',
                // 'parent_id' => '',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Bandas de Guerra y Escoltas',
                'parent_id' => '40',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Cultura',
                'parent_id' => '40',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Deportes',
                'parent_id' => '40',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            // 44
            [
                'name' => 'Proyectos Estratégicos Nacionales',
                // 'parent_id' => '',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Alfabetizatec',
                'parent_id' => '44',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'CIIT',
                'parent_id' => '44',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Gasolineras del Bienestar',
                'parent_id' => '44',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Plan Sonora',
                'parent_id' => '44',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Tren Maya',
                'parent_id' => '44',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Sembrando Vida',
                'parent_id' => '44',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            // 51
            [
                'name' => 'Vinculación',
                // 'parent_id' => '',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Concertación de Convenios',
                'parent_id' => '51',
                'url' => '/concertacion-convenios',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Consejos de Vinculación',
                'parent_id' => '51',
                'url' => '/consejos-vinculacion',
                'created_at' => date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Servicio Social y Residencias Profesionales',
                'parent_id' => '51',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            // 55
            [
                'name' => 'Noticias',
                // 'parent_id' => '',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Calendario',
                'parent_id' => '55',
                'url' => '/calendar',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            //57
            [
                'name' => 'Marco Normativo',
                // 'parent_id' => '',
                // 'url' => '',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
        DB::table('sections')->insert([
            [
                'name' => 'Lineamientos',
                'parent_id' => '57',
                'url' => '/#',
                'created_at' => date('Y-m-d H:m:s'),
            ],
        ]);
    }
}
