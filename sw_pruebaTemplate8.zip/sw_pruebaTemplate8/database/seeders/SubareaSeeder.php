<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SubareaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('subareas')->insert([
            [
                'name'      =>      'Fisica Cuantica',
                'status'    =>      '1',
                 'area_id'   =>      '1',
                 /*
                 'name_area'    =>      'Fisica Y Matematicas',
                 
                 */
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'name'      =>      'Matemcaticas Avanzada III',
                'status'    =>      '1',
                 'area_id'   =>      '1',
                 /*
              'name_area'    =>      'Fisica Y Matematicas',
              */
                'created_at' => date('Y-m-d H:m:s')
            ],
            [
                'name'      =>      'Psicologia',
                'status'    =>      '1',
                 'area_id'   =>      '3',
                 /*
                'name_area'    =>      'Hola',
                */
                'created_at' => date('Y-m-d H:m:s')
            ]
        ]);
    }
}
