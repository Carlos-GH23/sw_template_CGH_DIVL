<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SubareaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('subareas')->insert([
            [
                'name' => 'Astrofísica',
                'status' => 1,
                'area_id' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Astronomía',
                'status' => 1,
                'area_id' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias de la Tierra y del espacio',
                'status' => 1,
                'area_id' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Física',
                'status' => 1,
                'area_id' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Lógica',
                'status' => 1,
                'area_id' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Matemáticas',
                'status' => 1,
                'area_id' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Prospectiva',
                'status' => 1,
                'area_id' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias del mar',
                'status' => 1,
                'area_id' => 1,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias de la vida',
                'status' => 1,
                'area_id' => 2,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Prospectiva',
                'status' => 1,
                'area_id' => 2,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias biomédicas',
                'status' => 1,
                'area_id' => 2,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Biología',
                'status' => 1,
                'area_id' => 2,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Química',
                'status' => 1,
                'area_id' => 2,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias Ambientales',
                'status' => 1,
                'area_id' => 2,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias médicas',
                'status' => 1,
                'area_id' => 3,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Medicina',
                'status' => 1,
                'area_id' => 3,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Enfermería',
                'status' => 1,
                'area_id' => 3,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ingeniería biomédica',
                'status' => 1,
                'area_id' => 3,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Especialidad médica',
                'status' => 1,
                'area_id' => 3,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Odontología',
                'status' => 1,
                'area_id' => 3,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Investigación médica',
                'status' => 1,
                'area_id' => 3,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Biotecnología',
                'status' => 1,
                'area_id' => 4,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias agrarias',
                'status' => 1,
                'area_id' => 4,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Biotecnología agrícola',
                'status' => 1,
                'area_id' => 4,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Salud y Producción Animal',
                'status' => 1,
                'area_id' => 4,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Pesca',
                'status' => 1,
                'area_id' => 4,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Robótica',
                'status' => 1,
                'area_id' => 5,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Simulaciones',
                'status' => 1,
                'area_id' => 5,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Materiales avanzados',
                'status' => 1,
                'area_id' => 5,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Realidad virtual',
                'status' => 1,
                'area_id' => 5,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Realidad aumentada',
                'status' => 1,
                'area_id' => 5,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Big Data',
                'status' => 1,
                'area_id' => 5,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Inteligencia Artificial',
                'status' => 1,
                'area_id' => 5,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Software como servicio',
                'status' => 1,
                'area_id' => 5,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Manufactura aditiva',
                'status' => 1,
                'area_id' => 5,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias tecnólogicas',
                'status' => 1,
                'area_id' => 6,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ingeniería',
                'status' => 1,
                'area_id' => 6,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Prospectiva',
                'status' => 1,
                'area_id' => 6,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencia política',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias de la educación',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias económicas',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Ciencias jurídicas y derecho',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Demografía',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Formación docente',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Geografía',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Historia',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Sociología',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Prospectiva',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Administración y negocios',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Medios de comunicación y comunicaciones',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Comunicación Científica',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Gestión',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Estudios de Género',
                'status' => 1,
                'area_id' => 7,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Evaluación de reservas de litio',
                'status' => 1,
                'area_id' => 8,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Innovación en la explotación y transformación del litio',
                'status' => 1,
                'area_id' => 8,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Almacenamiento de energía',
                'status' => 1,
                'area_id' => 8,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Aplicaciones',
                'status' => 1,
                'area_id' => 8,
                'created_at'=> date('Y-m-d H:m:s'),
            ],
            [
                'name' => 'Comercialización, logística y transporte del litio',
                'status' => 1,
                'area_id' => 8,
                'created_at'=> date('Y-m-d H:m:s'),
            ],

        ]);
    }
}
