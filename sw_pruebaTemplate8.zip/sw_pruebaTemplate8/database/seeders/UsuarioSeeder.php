<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class UsuarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //creacion de usuarios
        DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA1', 'name' => 'Administrador',/* 'paternal_surname' => 'Gomez', 'maternal_surname' => 'Pineda' ,*/ 'email' => 'admin@gmail.com', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);
        DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA2', 'name' => 'Carlos',/* 'paternal_surname' => 'GONZALES', 'maternal_surname' => 'GUTIERREZ', */ 'email' => 'carlos@gmail.com', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);
        DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA3', 'name' => 'Diego',/* 'paternal_surname' => 'HERNANDEZ', 'maternal_surname' => 'LOPEZ',  */'email' => 'diego@gmail.com', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);
        DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA4', 'name' => 'Alex',/* 'paternal_surname' => 'BUSTOS', 'maternal_surname' => 'GIMENEZ',  */'email' => 'alex@gmail.com', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);
        // DB::table('users')->insert(['name' => 'Javier Villagran Placencio', 'email' => 'javi.yomy1928@gmail.com', 'password' => Hash::make('12345678'),]);
        
        // DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA2', 'name' => 'Javier Villagran Placencio', 'email' => 'vpjo200958@upemor.edu.mx', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);
        // DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA3', 'name' => 'Jose Antonio Ortega Martinez', 'email' => 'omjo200846@upemor.edu.mx', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]); 
        // DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA4', 'name' => 'Jose Santigo Heras Gomez', 'email' => 'hgjo200332@upemor.edu.mx', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);
        // DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA5', 'name' => 'Roman Chano Chano', 'email' => 'rcmo202029@upemor.edu.mx', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);

        // Roles del sistema
        $admin = Role::create(['name' => 'Admin', 'description' => 'Administrador']);

        $revisor = Role::create(['name' => 'Revisor', 'description' => 'Revisor de Estudiantes de Estadías']);
        
        $profesor = Role::create(['name' => 'Profesor', 'description' => 'Profesores para Estudiantes de Estadías']);
        
        $estudiante = Role::create(['name' => 'Estudiante', 'description' => 'Estudiante de Estudias']);



        User::find(1)->assignRole($admin);
        User::find(2)->assignRole($revisor);
        User::find(3)->assignRole($profesor);
        User::find(4)->assignRole($estudiante);
        // User::find(2)->assignRole($educacionContinua);
        // User::find(3)->assignRole($emprendimientoSocialTecnologico);
        // User::find(4)->assignRole($inovacionTransferenciaTecnologica);
        // User::find(5)->assignRole($intercambioAcademicoMovilidad);
    }
}
