<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class UsuarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //creacion de usuarios
        DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA1', 'name' => 'Administrador', 'email' => 'admin@gmail.com', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);
        // DB::table('users')->insert(['name' => 'Javier Villagran Placencio', 'email' => 'javi.yomy1928@gmail.com', 'password' => Hash::make('12345678'),]);
        
        // DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA2', 'name' => 'Javier Villagran Placencio', 'email' => 'vpjo200958@upemor.edu.mx', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);
        // DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA3', 'name' => 'Jose Antonio Ortega Martinez', 'email' => 'omjo200846@upemor.edu.mx', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]); 
        // DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA4', 'name' => 'Jose Santigo Heras Gomez', 'email' => 'hgjo200332@upemor.edu.mx', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);
        // DB::table('users')->insert(['curp' => 'VIPJ020514HMSLLVA5', 'name' => 'Roman Chano Chano', 'email' => 'rcmo202029@upemor.edu.mx', 'password' => Hash::make('12345678'), 'email_verified_at' => date('Y-m-d H:m:s'),]);

        // Roles del sistema
        $admin = Role::create(['name' => 'Admin', 'description' => 'Administrador']);
        
        $educacionContinua = Role::create(['name' => 'EducacionContinua', 'description' => 'Administrador de educación continua']);
        
        $emprendimientoSocialTecnologico = Role::create(['name' => 'EmprendimientoSocialTecnologico', 'description' => 'Administrador de Emprendimiento Social y Tecnológico']);

        $inovacionTransferenciaTecnologica = Role::create(['name' => 'InovacionTransferenciaTecnologica', 'description' => 'Administrador de Innovación Y Transferencia Tecnológica']);

        $intercambioAcademicoMovilidad = Role::create(['name' => 'IntercambioAcademicoMovilidad', 'description' => 'Administrador de Intercambio Académico Y Movilidad']);


        User::find(1)->assignRole($admin);
        // User::find(2)->assignRole($educacionContinua);
        // User::find(3)->assignRole($emprendimientoSocialTecnologico);
        // User::find(4)->assignRole($inovacionTransferenciaTecnologica);
        // User::find(5)->assignRole($intercambioAcademicoMovilidad);
    }
}
