<!--
<script setup>
import GuestLayout from '@/Layouts/GuestLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';

const form = useForm({
    name: '',
    email: '',
    password: '',
    password_confirmation: '',
});

const submit = () => {
    form.post(route('register'), {
        onFinish: () => form.reset('password', 'password_confirmation'),
    });
};
</script>

<template>
    <GuestLayout>
        <Head title="Register" />

        <form @submit.prevent="submit">
            <div>
                <InputLabel for="name" value="Name" />

                <TextInput
                    id="name"
                    type="text"
                    class="mt-1 block w-full"
                    v-model="form.name"
                    required
                    autofocus
                    autocomplete="name"
                />

                <InputError class="mt-2" :message="form.errors.name" />
            </div>

            <div>
                <InputLabel for="curp" value="CURP" />

                <TextInput
                    id="curp"
                    type="text"
                    class="mt-1 block w-full"
                    v-model="form.curp"
                    required
                    autofocus
                    autocomplete="curp"
                />

                <InputError class="mt-2" :message="form.errors.name" />
            </div>

            <div class="mt-4">
                <InputLabel for="email" value="Email" />

                <TextInput
                    id="email"
                    type="email"
                    class="mt-1 block w-full"
                    v-model="form.email"
                    required
                    autocomplete="username"
                />

                <InputError class="mt-2" :message="form.errors.email" />
            </div>

            <div class="mt-4">
                <InputLabel for="password" value="Password" />

                <TextInput
                    id="password"
                    type="password"
                    class="mt-1 block w-full"
                    v-model="form.password"
                    required
                    autocomplete="new-password"
                />

                <InputError class="mt-2" :message="form.errors.password" />
            </div>

            <div class="mt-4">
                <InputLabel for="password_confirmation" value="Confirm Password" />

                <TextInput
                    id="password_confirmation"
                    type="password"
                    class="mt-1 block w-full"
                    v-model="form.password_confirmation"
                    required
                    autocomplete="new-password"
                />

                <InputError class="mt-2" :message="form.errors.password_confirmation" />
            </div>

            <div class="flex items-center justify-end mt-4">
                <Link
                    :href="route('login')"
                    class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                    Already registered?
                </Link>

                <PrimaryButton class="ms-4" :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
                    Register
                </PrimaryButton>
            </div>
        </form>
    </GuestLayout>
</template>
-->

<script>
import { FwbInput } from 'flowbite-vue'

const name = ref('')

import { useForm, usePage } from "@inertiajs/vue3";
import { computed, ref, reactive } from "vue";
import {
    mdiAccount,
    mdiEmail,
    mdiFormTextboxPassword,
    mdiAsterisk,
    mdiLogout,
} from "@mdi/js";
import LayoutGuest from "@/Layouts/LayoutGuest.vue";
import SectionFullScreen from "@/Components/SectionFullScreen.vue";
import CardBox from "@/Components/CardBox.vue";
import FormCheckRadioGroup from "@/Components/FormCheckRadioGroup.vue";
import FormField from "@/Components/FormField.vue";
import FormControlRegister from "@/Components/FormControlRegister.vue";
import FormControl from "@/Components/FormControl.vue";
import BaseDivider from "@/Components/BaseDivider.vue";
import BaseButton from "@/Components/BaseButton.vue";
import BaseButtons from "@/Components/BaseButtons.vue";
import FormValidationErrors from "@/Components/FormValidationErrors.vue";
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue";
import axios from "axios";
import Loading from "vue-loading-overlay";
import "vue-loading-overlay/dist/css/index.css";
import Swal from "sweetalert2";

export default {
    props: {
        roles: {
            type: Object,
            required: true,
        },
    },
    components: {
        axios,
        Loading,
        LayoutGuest,
        SectionFullScreen,
        CardBox,
        FormCheckRadioGroup,
        FormField,
        FormControlRegister,
        FormControl,
        BaseDivider,
        BaseButtons,
        FormValidationErrors,
        BaseButton,
    },
    setup(props) {
        const form = useForm({
            name: "",
            paternal_surname: "",
            maternal_surname: "",
            email: "",
            password: "",
            password_confirmation: "",
            curp: "",
            role: "",
        });
        const isLoading = ref(false);
        const fullPage = true;
        const show = ref(true);

        const submit = () => {
            isLoading.value = true;
            form.post(route("register"), {
                onSuccess: (e) => {
                    form.reset();
                    
                    isLoading.value = false;
                },
                onFinish: () => {
                    isLoading.value = false;
                    form.reset(["password" | "password_confirmation"]);
                },
            });
        };

        

        const getData = () => {
            isLoading.value = true;
            axios
    .get(route("renapo.show", form.curp.toUpperCase()))
    .then((response) => {
        console.log(response.data); // Verifica que los datos sean los esperados
        isLoading.value = false;
        form.name = response.data.nombres;
        form.paternal_surname = response.data.apellidoPaterno;
        form.maternal_surname = response.data.apellidoMaterno;
    })
    .catch((error) => {
        isLoading.value = false;
        console.log(error);
                    if (error.response) {
                        if (error.response.status == 500) {
                            isLoading.value = false;
                            Swal.fire({
                                title: "Curp Incorrecta!",
                                text: "La curp ingresada no es valida, intente nuevamente",
                                icon: "warning",
                                confirmButtonColor: "#3085d6",
                                confirmButtonText: "Ok!",
                            });
                        }
                    } else if (error.request) {
                        isLoading.value = false;
                        Swal.fire({
                            title: "Error!",
                            text: "Lo sentimos hubo un error, intente nuevamente",
                            icon: "warning",
                            confirmButtonColor: "#3085d6",
                            confirmButtonText: "Ok!",
                        });
                    } else {
                        isLoading.value = false;
                        console.log("Error", error.message);
                    }
                    console.log(error.config);
                });
        };

        return {
            show,
            submit,
            form,
            getData,
            mdiLogout,
            mdiAsterisk,
            isLoading,
            fullPage,
            mdiAccount,
            mdiEmail,
            mdiFormTextboxPassword,
        };
    },
};
</script>
<template>
    <LayoutGuest>
        <div class="vl-parent">
            <loading v-model:active="isLoading" :can-cancel="false" :is-full-page="fullPage" />
        </div>

        <SectionFullScreen v-slot="{ cardClass }" bg="purplePink">
            <CardBox :class="cardClass" class="my-12">
                {{ roles }}

                <FormValidationErrors />

                <FormField label="Busqueda" help="Introduce tu curp">
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg aria-hidden="true" class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                            </svg>
                        </div>
                        <input type="search" id="default-search"
                            class="block w-full p-4 pl-10 text-sm text-gray-700 border border-gray-300 rounded-lg bg-white focus:ring-blue-500 focus:border-blue-500 dark:bg-slate-800 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            v-model="form.curp" required>
                        <button @click="getData"
                            class="text-white absolute right-2.5 bottom-2.5 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Buscar</button>
                    </div>
                </FormField>

                <div @submit.prevent="submit">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField label="Nombre" label-for="name">
                            <FormControlRegister v-model="form.name" id="name" :icon="mdiAccount" autocomplete="off" type="text" required />
                        </FormField>

                        <FormField label="Apellido Paterno" label-for="paternal_surname">
                            <FormControlRegister v-model="form.paternal_surname" id="paternal_surname" :icon="mdiAccount" autocomplete="off" type="text" required />
                        </FormField>

                        <FormField label="Apellido Materno" label-for="maternal_surname">
                            <FormControlRegister v-model="form.maternal_surname" id="maternal_surname" :icon="mdiAccount" autocomplete="off" type="text" required />
                        </FormField>

                        <FormField label="Email" label-for="email" help="Introduce tu correo electronico">
                            <FormControl v-model="form.email" id="email" :icon="mdiEmail" type="text" />
                        </FormField>

                        <FormField label="Contraseña" label-for="password" help="Introduce tu contraseña">
                            <FormControl v-model="form.password" :icon="mdiAsterisk" type="password" id="password" autocomplete="current-password" required />
                        </FormField>

                        <FormField label="Confirma Contraseña" label-for="password_confirmation" help="Confirma tu contraseña">
                            <FormControl v-model="form.password_confirmation" :icon="mdiAsterisk" type="password" id="password_confirmation" autocomplete="current-password" required />
                        </FormField>
                    </div>

                    <BaseButtons class="mt-4">
                        <BaseButton @click="submit" type="submit" color="info" label="Registrarse"
                            :class="{ 'opacity-25': form.processing }" :disabled="form.processing" />
                        <BaseButton route-name="login" color="info" outline label="Volver al inicio de sesion" />
                    </BaseButtons>
                </div>


            </CardBox>
        </SectionFullScreen>
    </LayoutGuest>
</template>
