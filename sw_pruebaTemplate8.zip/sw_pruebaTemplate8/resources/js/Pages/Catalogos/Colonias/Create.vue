<script setup>
import CardBox from "@/Components/CardBox.vue";
import LayoutMain from "@/Layouts/LayoutMain.vue";
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue";
import { mdiBallotOutline, mdiInformation, mdiPlus, mdiPencil, mdiTrashCan, mdiContentSave, mdiClose } from "@mdi/js";
import NotificationBar from "@/Components/NotificationBar.vue";
import BaseButton from "@/Components/BaseButton.vue";
import BaseButtons from "@/Components/BaseButtons.vue";

import { defineProps } from 'vue';
import { Link, Head, router } from "@inertiajs/vue3";

import JetInput from "@/Components/Input.vue";
import JetInputError from "@/Components/InputError.vue";
import JetButton from "@/Components/Button.vue";
import { useForm } from "@inertiajs/vue3";


const props = defineProps({
    name: 'Create',
    titulo: {
        type: String,
        required: true
    },
    municipios: { type: Object, required: true },

    estados: {
        type: Object,
        required: true
    },

  

    routeName: {
        type: String,
        required: true
    },
});
const form = useForm({ municipio_id:'', name: '', codigo_postal: '', estado_id: '' });
const guardar = () => {
    form.post(route("colonia.store"));
};




</script>

<template>
    <Head :title="titulo">
        <link rel="shortcut icon" type="image/png" href="/img/TecnmBlanco.png">
    </Head>
    <LayoutMain>
        <SectionTitleLineWithButton :icon="mdiPlus" :title="titulo" main>
            <a :href="route(`${routeName}index`)">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-x"
                    viewBox="0 0 16 16">
                    <path
                        d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                </svg>
            </a>
        </SectionTitleLineWithButton>

        <CardBox form @submit.prevent="guardar">
            <div class="mb-6">
                <label for="municipio_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    <span class="text-red-600 mr-1">*</span>Nombre del Municipio
                </label>

                <select id="municipio_id"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    v-model="form.municipio_id">
                    <option value="">
                        Seleccione una opción
                    </option>
                    <option v-for="item in municipios" v-bind:value="item.id" v-bind:key="item.id">
                        {{ item.name }}
                    </option>
                </select>
                <jet-input-error :message="form.errors.municipio_id" />
            </div>


            
            
            <div class="mb-6">
                <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    <span class="text-red-600 mr-1">*</span>Nombre de la colonia:
                </label>
                <jet-input id="name"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    v-model="form.name" required
                    placeholder="Nombre del Area" />
                <jet-input-error :message="form.errors.name" />
            </div>

            <div class="mb-6">
                <label for="codigo_postal" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    <span class="text-red-600 mr-1">*</span>Codigo Postal:
                </label>
                <jet-input id="codigo_postal"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    v-model="form.codigo_postal" required
                    placeholder="Nombre del Area" />
                <jet-input-error :message="form.errors.codigo_postal" />
            </div>
          
            <template #footer>
                <BaseButtons>
                    <BaseButton :href="route(`${routeName}index`)" :icon="mdiClose" color="danger" label="Cancelar" />
                    <BaseButton @click="guardar" :icon="mdiContentSave" type="submit" color="info" label="Guardar" />
                </BaseButtons>
            </template>
        </CardBox>
    </LayoutMain>
</template>
