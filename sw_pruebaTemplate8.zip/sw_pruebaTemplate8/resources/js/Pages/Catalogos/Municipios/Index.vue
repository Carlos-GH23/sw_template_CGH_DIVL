<script setup>
import CardBox from "@/Components/CardBox.vue";
import LayoutMain from "@/Layouts/LayoutMain.vue";
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue";
import {
    mdiBallotOutline,
    mdiInformation,
    mdiBroom,
    mdiPencil,
    mdiRefresh,
} from "@mdi/js";
import NotificationBar from "@/Components/NotificationBar.vue";
import BaseButton from "@/Components/BaseButton.vue";
import BaseButtons from "@/Components/BaseButtons.vue";
import CardBoxComponentEmpty from "@/Components/CardBoxComponentEmpty.vue";
import { defineProps } from "vue";
import { Link, Head, router } from "@inertiajs/vue3";
import JetInput from "@/Components/Input.vue";
import Pagination from "@/Shared/Pagination.vue";
import { computed, reactive, ref } from "vue";
import Loading from "vue-loading-overlay";
import "vue-loading-overlay/dist/css/index.css";
import { FwbCard } from "flowbite-vue";

const props = defineProps({
    name: 'Index',
    titulo: {
        type: String,
        required: true
    },
    municipios: {
        type: Object,
        required: true
    },
    routeName: {
        type: String,
        required: true
    },
    loadingResults: { type: Boolean, required: true, default: true },
    search: { type: String, required: true },
    status: { type: Boolean, required: true, default: true },
});

const isLoading = ref(false);
const state = reactive({
    filters: {
        page: ref(props.municipios.current_page),
        search: ref(props.search),
        status: ref(props.status ?? 1),
    },
});

const search = () => {
    isLoading.value = true;
    router.get(route(`${props.routeName}index`, state.filters));
};

const cleanFilters = () => {
    isLoading.value = true;
    state.filters.search = '';
    state.filters.status = 1;
    router.get(route(`${props.routeName}index`));
};
</script>

<template>
    <Head :title="titulo">
        <link rel="shortcut icon" type="image/png" href="/img/TecnmBlanco.png">
    </Head>
    <LayoutMain>
        <SectionTitleLineWithButton :icon="mdiBallotOutline" :title="titulo" main>
            <BaseButton :href="route(`${routeName}create`)" color="info" label="+ Agregar" />
        </SectionTitleLineWithButton>

        <NotificationBar v-if="$page.props.flash.success" color="success" :icon="mdiInformation" :outline="false">
            {{ $page.props.flash.success }}
        </NotificationBar>

        <NotificationBar v-if="$page.props.flash.error" color="danger" :icon="mdiInformation" :outline="false">
            {{ $page.props.flash.error }}
        </NotificationBar>

        <form class="w-full mb-5">
            <div class="flex flex-col md:flex-row">
                <div class="relative w-full md:w-4/5 mr-1">
                    <input
                        type="search"
                        id="search-dropdown"
                        class="block p-2.5 md:h-11 w-full z-20 text-sm text-gray-900 bg-gray-50 rounded-l-lg md:rounded-l-none rounded-r-lg md:border-l-gray-300 border-l-gray-300 border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-l-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-blue-500"
                        placeholder="Ingresa un parametro de busqueda"
                        v-model="state.filters.search"
                        @change="search"
                    />
                    <button
                        type="submit"
                        class="absolute top-0 right-0 p-2.5 text-sm font-medium h-full md:h-11 xl:h-full text-white bg-blue-700 rounded-r-lg border border-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        @click.prevent="search"
                    >
                        <svg
                            class="w-4 h-4"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 20 20"
                        >
                            <path
                                stroke="currentColor"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                            />
                        </svg>
                        <span class="sr-only">Search</span>
                    </button>
                </div>
                
                <BaseButton
                    class="md:w-1/5 md:mt-0 md:h-11 max-xl:mt-4 mr-1"
                    @click="cleanFilters"
                    :icon="mdiBroom"
                    color="danger"
                    label="Limpiar"
                />
            </div>
        </form>

        <CardBox v-if="municipios.data.length > 0">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
    <fwb-card v-for="item in municipios.data" :key="item.id" class="shadow-lg border rounded-lg transition-transform transform hover:scale-105 dark:bg-gray-800 dark:border-gray-700">
        <div class="p-5">
            <div class="w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center mb-4">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="text-gray-500 dark:text-gray-300" viewBox="0 0 24 24">
  <path d="M12 2L2 7v10l10 5 10-5V7l-10-5zm0 2.14L20 8v8l-8 4-8-4V8l8-3.86z"/>
  <path d="M12 11.57l3.46 1.8-1.38-3.96L12 9l-2.08 1.42L8.54 13.37 12 11.57z"/>
</svg>





            </div>
            <h5 class="mb-2 text-m font-bold tracking-tight text-gray-900 dark:text-white">
                {{ item.name }}
            </h5>
            <p class="mb-4 text-sm text-gray-900 dark:text-white">
                Fecha de Creacion: {{ new Date(item.created_at).toLocaleString() }}
            </p>
            <div>
                <BaseButton color="success"
                    :icon="mdiPencil"
                    small
                    :href="route(`${routeName}edit`, item.id)"
                    label="Editar" />
            </div>
        </div>
    </fwb-card>
</div>
        </CardBox>
        <CardBoxComponentEmpty v-else />
        <pagination :links="municipios.links" :total="municipios.total" />
        <div class="vl-parent">
            <loading v-model:active="isLoading" :can-cancel="false" :is-full-page="true" />
        </div>
    </LayoutMain>
</template>
