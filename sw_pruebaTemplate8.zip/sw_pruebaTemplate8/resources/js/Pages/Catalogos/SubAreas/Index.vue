<script setup>
import CardBox from "@/Components/CardBox.vue";
import LayoutMain from "@/Layouts/LayoutMain.vue";
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue";
import {
    mdiBallotOutline,
    mdiInformation,
    mdiBroom,
    mdiPencil,
    mdiRefresh,
} from "@mdi/js";
import NotificationBar from "@/Components/NotificationBar.vue";
import BaseButton from "@/Components/BaseButton.vue";
import BaseButtons from "@/Components/BaseButtons.vue";
import CardBoxComponentEmpty from "@/Components/CardBoxComponentEmpty.vue";
import { defineProps } from "vue";
import { Link, Head, router } from "@inertiajs/vue3";
import JetInput from "@/Components/Input.vue";
import Pagination from "@/Shared/Pagination.vue";
import { computed, reactive, ref } from "vue";
import Loading from "vue-loading-overlay";
import "vue-loading-overlay/dist/css/index.css";
import { FwbCard } from "flowbite-vue";

const props = defineProps({
    name: "Index",
    titulo: {
        type: String,
        required: true,
    },
    subareas: {
        type: Object,
        required: true,
    },
    /*  areas:{
        type: Object,
        required: true
    },
     */
    routeName: {
        type: String,
        required: true,
    },
    loadingResults: { type: Boolean, required: true, default: true },
    search: { type: String, required: true },
    status: { type: Boolean, required: true, default: true },
});

const isLoading = ref(false);
const thereAreResults = computed(() => props.subareas.total > 0);

const state = reactive({
    filters: {
        page: ref(props.subareas.current_page),
        search: ref(props.search),
        status: ref(props.status ?? 1),
    },
});

const search = () => {
    isLoading.value = true;
    router.get(route(`${props.routeName}index`, state.filters));
};

const cleanFilters = () => {
    isLoading.value = true;
    state.filters.search = "";
    state.filters.status = 1;
    router.get(route(`${props.routeName}index`));
};
</script>

<template>
    <Head :title="titulo">
        <link
            rel="shortcut icon"
            type="image/png"
            href="/img/TecnmBlanco.png"
        />
    </Head>
    <LayoutMain>
        <SectionTitleLineWithButton
            :icon="mdiBallotOutline"
            :title="titulo"
            main
        >
            <BaseButton
                :href="route(`${routeName}create`)"
                color="info"
                label="+ Agregar"
               
            />
        </SectionTitleLineWithButton>

        <NotificationBar
            v-if="$page.props.flash.success"
            color="success"
            :icon="mdiInformation"
            :outline="false"
            
        >
            {{ $page.props.flash.success }}
        </NotificationBar>

        <NotificationBar
            v-if="$page.props.flash.error"
            color="danger"
            :icon="mdiInformation"
            :outline="true"
            class="mb-4 border-2 border-red-400 bg-red-50 text-red-800"
        >
            {{ $page.props.flash.error }}
        </NotificationBar>

        <form class="w-full mb-5">
            <div class="flex flex-col md:flex-row items-center">
                <div class="relative w-full md:w-4/5 mr-1">
                    <input
                        type="search"
                        id="search-dropdown"
                        class="block p-3 md:h-12 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 shadow-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-blue-500"
                        placeholder="Buscar..."
                        v-model="state.filters.search"
                        @change="search"
                    />
                    <button
                        type="submit"
                        class="absolute top-0 right-0 p-3 text-sm font-medium h-full md:h-12 text-white bg-blue-600 rounded-r-lg border border-blue-600 hover:bg-blue-700 focus:ring-2 focus:ring-blue-500"
                        @click.prevent="search"
                    >
                        <svg
                            class="w-4 h-4"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 20 20"
                        >
                            <path
                                stroke="currentColor"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                            />
                        </svg>
                        <span class="sr-only">Buscar</span>
                    </button>
                </div>

                <BaseButton
                    class="md:w-1/5 md:mt-0 md:h-12 mt-4"
                    @click="cleanFilters"
                    :icon="mdiBroom"
                    color="danger"
                    label="Limpiar"
                />
            </div>
        </form>

        <CardBox v-if="thereAreResults">
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <fwb-card 
            v-for="item in subareas.data" 
            :key="item.id" 
            class="transition-transform transform hover:scale-105 hover:shadow-lg dark:hover:shadow-none border border-gray-200 dark:border-gray-700 rounded-lg"
        >
            <div class="p-4 bg-white dark:bg-gray-800 rounded-lg">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center">
                       
 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="text-gray-500 dark:text-gray-300" viewBox="0 0 24 24">
    <path d="M3 3h7v7H3V3zm0 10h7v7H3v-7zm10-10h7v7h-7V3zm0 10h7v7h-7v-7z"/>
</svg>





                    </div>
                    <h5 class="ml-4 text-lg font-semibold text-gray-900 dark:text-white">
                        {{ item.subarea_name }}
                    </h5>
                </div>
                <p class="mb-2 text-sm text-gray-700 dark:text-gray-400">
                    Área: {{ item.area_name }}
                </p>
                <p class="mb-2 text-xs text-gray-600 dark:text-gray-300">
                    Fecha de Creación: {{ item.subarea_creacion }}
                </p>
                <div class="mb-4 flex items-center">
                <span v-if="item.subarea_status == 1" class="flex items-center text-blue-700 font-bold text-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="mr-2" viewBox="0 0 16 16">
                        <path d="M8 0a8 8 0 1 0 8 8A8 8 0 0 0 8 0zM8 15a7 7 0 1 1 0-14 7 7 0 0 1 0 14zM8 7.293L6.707 5.707a1 1 0 1 1 1.414-1.414L8 5.586l1.879-1.879a1 1 0 1 1 1.414 1.414L8 7.293z"/>
                    </svg>
                    Activo
                </span>
                <span v-if="item.subarea_status == 0" class="flex items-center text-red-700 font-bold text-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="mr-2" viewBox="0 0 16 16">
                        <path d="M8 0a8 8 0 1 0 8 8A8 8 0 0 0 8 0zM8 15a7 7 0 1 1 0-14 7 7 0 0 1 0 14zM8 5.707L6.707 7.707a1 1 0 1 1-1.414-1.414L6.293 4.586a1 1 0 1 1 1.414-1.414L8 5.707z"/>
                    </svg>
                    No activo
                </span>
            </div>
                <div class="mt-4">
                    <BaseButton
                        color="success"
                    :icon="mdiPencil"
                    small
                    :href="route(`${routeName}edit`, item.id)"
                    label="Editar"
                    />
                </div>
            </div>
        </fwb-card>
    </div>
        </CardBox>
        <CardBoxComponentEmpty v-else />
        <Pagination :links="subareas.links" :total="subareas.total" />
        <div class="vl-parent">
            <Loading
                v-model:active="isLoading"
                :can-cancel="false"
                :is-full-page="true"
                color="blue"
                :spinner="true"
            />
        </div>
    </LayoutMain>
</template>


