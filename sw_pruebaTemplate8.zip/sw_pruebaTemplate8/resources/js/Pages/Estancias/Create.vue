<script setup>
import CardBox from '@/Components/CardBox.vue';
import LayoutMain from '@/Layouts/LayoutMain.vue';
import SectionTitleLineWithButton from '@/Components/SectionTitleLineWithButton.vue';
import {
    mdiBallotOutline,
    mdiInformation,
    mdiPencil,
    mdiTrashCan,
    mdiContentSave,
    mdiClose,
    mdiMagnify
} from "@mdi/js";
import NotificationBar from "@/Components/NotificationBar.vue";
import BaseButton from "@/Components/BaseButton.vue";
import BaseButtons from "@/Components/BaseButtons.vue";
import { defineProps, ref, computed, watch, reactive, onMounted } from "vue";
import { Link, Head, useForm, usePage } from "@inertiajs/vue3";
import FormField from "@/Components/FormField.vue";
import FormControl from "@/Components/FormControl.vue";
import FormControlRegister from '@/Components/FormControlRegister.vue';
import BaseDivider from "@/Components/BaseDivider.vue";
import BaseIcon from "@/Components/BaseIcon.vue";
import CardBoxComponentEmpty from "@/Components/CardBoxComponentEmpty.vue";
import { Tabs, Tab } from "flowbite-vue";
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import { provide, watchEffect } from "@vue/runtime-core";
import axios from "axios"
import Loading from 'vue-loading-overlay';
import 'vue-loading-overlay/dist/css/index.css';
import JetInputError from "@/Components/InputError.vue";


const props = defineProps({
     name: 'Create',
    titulo: {
        type: String,
        required: true
    },

    routeName: {
        type: String,
        required: true
    },

    users: {
        type: Object,
        required: true
    },

    proyectos:{
        type: Object,
        required:true
    },

    areas:{
        type: Object,
        required: true
    },

    subareas: {
        type: Object,
        required: true
    },

    estados:{
        type: Object,
        required: true
    },

    colonias:{
        type: Object,
        required: true
    },

    tipo_estancias:{
        type: Object,
        required: true
    }
});





</script>