<script setup>
import CardBox from "@/Components/CardBox.vue";
import LayoutMain from "@/Layouts/LayoutMain.vue";
import SectionTitleLineWithButton from "@/Components/SectionTitleLineWithButton.vue";
import {
    mdiBallotOutline,
    mdiAccount,
    mdiMail,
    mdiInformation,
    mdiPencil,
    mdiBroom,
    mdiEyePlus,
    mdiEyeClosed,
} from "@mdi/js";
import NotificationBar from "@/Components/NotificationBar.vue";
import BaseButton from "@/Components/BaseButton.vue";
import CardBoxComponentEmpty from "@/Components/CardBoxComponentEmpty.vue";
import { defineProps } from "vue";
import { Link, Head, router } from "@inertiajs/vue3";
import JetButton from "@/Components/Button.vue";
import JetInput from "@/Components/Input.vue";

import Pagination from "@/Shared/Pagination.vue";
import RecordsHelper from "@/Shared/RecordsHelper.vue";
import { computed, onMounted, reactive, ref, watch } from "vue";
import Loading from "vue-loading-overlay";
import "vue-loading-overlay/dist/css/index.css";
import { FwbCard } from "flowbite-vue";

const props = defineProps({
    name: "Index",
    titulo: {
        type: String,
        required: true,
    },

    isDarkMode: {
        type: Boolean,
        default: false,
    },
    estancias: {
        type: Object,
        required: true,
    },
    routeName: {
        type: String,
        required: true,
    },
    loadingResults: { type: Boolean, required: true, default: true },
    search: { type: String, required: true },
    status: { type: Boolean, required: true, default: true },
});

const isLoading = ref(false);
const thereAreResults = computed(() => props.estancias.total > 0);
const state = reactive({
    filters: {
        page: ref(props.estancias.current_page),
        search: ref(props.search),
        status: ref(props.status ?? 1),
    },
});
const search = () => {
    isLoading.value = true;
    router.get(route(`${props.routeName}index`, state.filters));
};
const cleanFilters = () => {
    isLoading.value = true;
    router.get(route(`${props.routeName}index`));
};

const isModalOpen = ref(false);
const modalData = ref({});
const modalType = ref("");

const openModal = (item, type) => {
    modalData.value = item;
    modalType.value = type;
    isModalOpen.value = true;
};

const closeModal = () => {
    isModalOpen.value = false;
};

const getFirstName = (fullName) => {
    const parts = fullName.split(" ");
    return parts.length > 1 ? parts.slice(0, -2).join(" ") : ""; // Nombre(s) puede ser más de una palabra
};

const getPaternalSurname = (fullName) => {
    const parts = fullName.split(" ");
    return parts.length > 1 ? parts[parts.length - 2] : ""; // Último pero uno antes del último
};

const getMaternalSurname = (fullName) => {
    const parts = fullName.split(" ");
    return parts.length > 1 ? parts[parts.length - 1] : ""; // Último
};
</script>

<template>
    <Head :title="titulo">
        <link
            rel="shortcut icon"
            type="image/png"
            href="/img/TecnmBlanco.png"
        />
    </Head>
    <LayoutMain>
        <SectionTitleLineWithButton
            :icon="mdiBallotOutline"
            :title="titulo"
            main
        >
            <BaseButton
                :href="route(`${routeName}create`)"
                color="info"
                label="+ Agregar"
            />
        </SectionTitleLineWithButton>

        <NotificationBar
            v-if="$page.props.flash.success"
            color="success"
            :icon="mdiInformation"
            :outline="false"
        >
            {{ $page.props.flash.success }}
        </NotificationBar>

        <NotificationBar
            v-if="$page.props.flash.error"
            color="danger"
            :icon="mdiInformation"
            :outline="false"
        >
            {{ $page.props.flash.error }}
        </NotificationBar>

        <form class="w-full mb-5">
            <div class="flex flex-col md:flex-row">
                <div class="relative w-full md:w-4/5 mr-1">
                    <input
                        type="search"
                        id="search-dropdown"
                        class="block p-2.5 md:h-11 w-full z-20 text-sm text-gray-900 bg-gray-50 rounded-l-lg md:rounded-l-none rounded-r-lg md:border-l-gray-300 border-l-gray-300 border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-l-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-blue-500"
                        placeholder="Ingresa un parametro de busqueda"
                        v-model="state.filters.search"
                        @change="search"
                    />
                    <button
                        type="submit"
                        class="absolute top-0 right-0 p-2.5 text-sm font-medium h-full md:h-11 xl:h-full text-white bg-blue-700 rounded-r-lg border border-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        @click.prevent="search"
                    >
                        <svg
                            class="w-4 h-4"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 20 20"
                        >
                            <path
                                stroke="currentColor"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                            />
                        </svg>
                        <span class="sr-only">Search</span>
                    </button>
                </div>

                <BaseButton
                    class="md:w-1/5 md:mt-0 md:h-11 max-xl:mt-4 mr-1"
                    @click="cleanFilters"
                    :icon="mdiBroom"
                    color="danger"
                    label="Limpiar"
                />
            </div>
        </form>

        <!-- <CardBox v-if="records.data.length > 0"  has-table> -->
        <CardBox v-if="thereAreResults">
            <div>
                <div
                    class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6"
                >
                    <!-- Tarjeta Principal -->
                    <fwb-card
                        href="#"
                        v-for="item in estancias.data"
                        :key="item.id"
                        class="relative p-6 bg-white dark:bg-gray-800 shadow-lg rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col transform transition-transform duration-300 hover:shadow-xl hover:-translate-y-1"
                    >
                        <div class="flex-grow">
                            <!-- Título y contenido de la tarjeta -->
                            <h5
                                class="mb-3 text-xl font-bold text-gray-900 dark:text-white"
                            >
                                Información Personal
                            </h5>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Nombre(s):
                                </span>
                                <p class="line-clamp-2">
                                    {{ getFirstName(item.user_name) }}
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Apellido Paterno:
                                </span>
                                <p class="line-clamp-2">
                                    {{ getPaternalSurname(item.user_name) }}
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Apellido Materno:
                                </span>
                                <p class="line-clamp-2">
                                    {{ getMaternalSurname(item.user_name) }}
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Edad:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.estancia_age }} años
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    CURP:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.user_curp }}
                                </p>
                            </div>

                            <BaseButton
                                color="info"
                                :icon="mdiEyePlus"
                                small
                                @click="openModal(item, 'personal')"
                                class="mt-4"
                            >
                                Ver Más
                            </BaseButton>
                        </div>
                    </fwb-card>

                    <!-- Tarjeta Adicional -->
                    <fwb-card
                        href="#"
                        v-for="item in estancias.data"
                        :key="item.id"
                        class="relative p-6 bg-white dark:bg-gray-800 shadow-lg rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col transform transition-transform duration-300 hover:shadow-xl hover:-translate-y-1"
                    >
                        <div class="flex-grow">
                            <h5
                                class="mb-3 text-xl font-bold text-gray-900 dark:text-white"
                            >
                                Información Sobre Estancia
                            </h5>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Horas a Cubrir:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.hour }} horas
                                </p>
                            </div>

                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Horario Seleccioando:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.schedule }}
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Fecha de Incio:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.start_date }}
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Fecha de Finalizacion:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.ending_date }}
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Tipo de Estancia a Realizar:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.tipo_estancia_name }}
                                </p>
                            </div>

                            <BaseButton
                                color="info"
                                :icon="mdiEyePlus"
                                small
                                @click="openModal(item, 'estancia')"
                                class="mt-4"
                            >
                                Ver Más
                            </BaseButton>
                        </div>
                    </fwb-card>

                    <fwb-card
                        href="#"
                        v-for="item in estancias.data"
                        :key="item.id"
                        class="relative p-6 bg-white dark:bg-gray-800 shadow-lg rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col transform transition-transform duration-300 hover:shadow-xl hover:-translate-y-1"
                    >
                        <div class="flex-grow">
                            <h5
                                class="mb-3 text-xl font-bold text-gray-900 dark:text-white"
                            >
                                Institucion de Procedencia
                            </h5>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Nombre de la Institucion:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.institutions_name_complete }} 
                                </p>
                            </div>

                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Estado:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.state }}
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Municipio:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.municipality }}
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Telefono de la Institucion:
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.phone_number_institution }}
                                </p>
                            </div>
                            <div class="mb-3">
                                <span
                                    class="font-semibold text-blue-600 dark:text-blue-400"
                                >
                                    Nombre del Rector(a)/Director(a):
                                </span>
                                <p class="line-clamp-2">
                                    {{ item.rectors_name }}
                                </p>
                            </div>

                            <BaseButton
                                color="info"
                                :icon="mdiEyePlus"
                                small
                                @click="openModal(item, 'institucion')"
                                class="mt-4"
                            >
                                Ver Más
                            </BaseButton>
                        </div>
                    </fwb-card>
                </div>

                <!-- Modal -->
                <transition name="fade">
                    <div
                        v-if="isModalOpen"
                        class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
                    >
                        <div
                            class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg max-w-4xl w-full"
                        >
                            <div
                                class="flex justify-between items-center border-b border-gray-200 dark:border-gray-700 pb-3 mb-4"
                            >
                                <h3
                                    class="text-xl font-bold text-gray-900 dark:text-white"
                                >
                                    {{
                                        modalType === "personal"
                                            ? "Información Personal Registrada"
                                            : modalType === "estancia"
                                            ? "Información Sobre Estancia Registrada"
                                            : modalType === "institucion"
                                            ? "Información Institucional Registrada"
                                            : "Información No Disponible"
                                    }}
                                </h3>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <!-- Contenido del Modal -->

                                <!-- Informacion de Nombre(s) PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Nombre(s):
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ getFirstName(modalData.user_name) }}
                                    </p>
                                </div>

                                <!-- Informacion de horas REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Horas a Cubrir:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.hour }}
                                    </p>
                                </div>

                                <!-- Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Nombre de la Institucion:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.institutions_name_complete }}
                                    </p>
                                </div>

                                <!-- Informacion de Apellido Paterno PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Apellido Paterno:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{
                                            getPaternalSurname(
                                                modalData.user_name
                                            )
                                        }}
                                    </p>
                                </div>

                                <!-- Informacion de Horario REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Horario en la Institucion:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.schedule }}
                                    </p>
                                </div>

                                <!-- Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Estado:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.state }}
                                    </p>
                                </div>

                                <!-- Informacion de Apellido Materno PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Apellido Materno:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{
                                            getMaternalSurname(
                                                modalData.user_name
                                            )
                                        }}
                                    </p>
                                </div>

                                <!-- Informacion de Fecha Inicio REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Fecha de Inicio:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.start_date }}
                                    </p>
                                </div>

                                <!--Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Municipio:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.municipality }}
                                    </p>
                                </div>

                                

                                <!-- Informacion de Edad PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Edad:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.estancia_age }} años
                                    </p>
                                </div>

                                <!-- Informacion de Fecha Fin REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Fecha de Fin:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.ending_date }}
                                    </p>
                                </div>

                                <!-- Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Telefono de la Institucion:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.phone_number_institution }}
                                    </p>
                                </div>

                                <!-- Informacion de CURP PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        CURP:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.user_curp }}
                                    </p>
                                </div>

                                <!-- Informacion de Tipo de Estancia REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Tipo de Estancia a Realizar:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.tipo_estancia_name }}
                                    </p>
                                </div>

                                <!-- Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Nivel Academico:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.level }}
                                    </p>
                                </div>

                                <!-- Informacion de Genero PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Sexo:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.gender }}
                                    </p>
                                </div>

                                <!-- Informacion de Nombre del Profesor REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Nombre del Profesor:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{modalData.degree}}  {{ modalData.proyecto_user_name }} <!-- Queda Pendiente de Momento -->
                                    </p>
                                </div>

                                <!-- Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Numero de Matricula/Control:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.registration_number }}
                                    </p>
                                </div>

                                <!-- Informacion de Estado PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Estado:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.estado_name }}
                                    </p>
                                </div>

                                 <!-- Informacion Nombre del Proyecto REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Nombre del Proyecto:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.proyecto_name }} 
                                    </p>
                                </div>

                                <!-- Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Nombre del Rector(a)/Director(a):
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.rectors_name }}
                                    </p>
                                </div>

                                <!-- Informacion de Municipio PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Municipio:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.municipio_name }}
                                    </p>
                                </div>

                                <!-- Informacion Nombre del Proyecto REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Nombre del Departamento:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.departamento_name }} 
                                    </p>
                                </div>

                                <!-- Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Semestre/Cuatrimestre/Trimestres:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.semester }}
                                    </p>
                                </div>

                                <!-- Informacion de Colonia PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Colonia:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.colonia_name }}
                                    </p>
                                </div>

                                 <!-- Informacion Nombre del Proyecto REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Area del Proyecto:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.area_name }} 
                                    </p>
                                </div>

                                <!-- Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Carrera:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.career }}
                                    </p>
                                </div>

                                <!-- Informacion de Numero de Telefono PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Teléfono:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.phone_number }}
                                    </p>
                                </div>

                                <!-- Informacion Nombre del Proyecto REGISTRO -->
                                <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        SubArea del Proyecto:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.subarea_name }} 
                                    </p>
                                </div>

                                <!-- Informacion de nombre de la Institucion Institucion -->
                                <div v-if="modalType === 'institucion'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Especialidad:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.speciality }}
                                    </p>
                                </div>

                                <!-- Informacion de Numero Interior PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        No. Exterior:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.outdoor_number }}
                                    </p>
                                </div>


                                <!-- Informacion Nombre del Proyecto REGISTRO -->
                               <!--  <div v-if="modalType === 'estancia'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Grado del Profesor:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.degree }} 
                                    </p>
                                </div> -->

                        

                                <!-- Informacion de Numero Exterior PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        No. Interior:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.interior_number }}
                                    </p>
                                </div>

                                <!-- Informacion de Codigo postal PERSONAL -->
                                <div v-if="modalType === 'personal'">
                                    <span
                                        class="font-semibold text-blue-600 dark:text-blue-400"
                                    >
                                        Código Postal:
                                    </span>
                                    <p class="text-gray-700 dark:text-gray-300">
                                        {{ modalData.zip_code }}
                                    </p>
                                </div>
                            </div>

                            <div class="mt-6 flex justify-end">
                                <BaseButton
                                    color="info"
                                    :icon="mdiEyeClosed"
                                    small
                                    @click="closeModal"
                                >
                                    Cerrar
                                </BaseButton>
                            </div>
                        </div>
                    </div>
                </transition>
            </div>
        </CardBox>
        <CardBoxComponentEmpty v-else />


<!--         {{ estancias }}
 -->
        <div class="vl-parent">
            <loading
                v-model:active="isLoading"
                :can-cancel="false"
                :is-full-page="true"
            />
        </div>
    </LayoutMain>
</template>
<style>
@import "tailwindcss/tailwind.css";

@media (max-width: 768px) {
    thead {
        display: none;
    }

    table tbody tr {
        display: block;
        border: 1px solid #ddd;
        margin-bottom: 1rem;
    }

    table tbody tr td {
        display: flex;
        justify-content: space-between;
        padding: 0.5rem;
        border-bottom: 1px solid #ddd;
    }

    table tbody tr td:last-child {
        border-bottom: none;
    }

    table tbody tr td[data-label]:before {
        content: attr(data-label);
        font-weight: bold;
        text-transform: uppercase;
        margin-right: 0.5rem;
    }
}
</style>
