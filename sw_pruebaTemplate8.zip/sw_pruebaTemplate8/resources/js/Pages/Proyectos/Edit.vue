<script setup>
import { ref, computed } from 'vue';
import CardBox from '@/Components/CardBox.vue';
import LayoutMain from '@/Layouts/LayoutMain.vue';
import SectionTitleLineWithButton from '@/Components/SectionTitleLineWithButton.vue';
import { mdiBallotOutline, mdiInformation, mdiPlus, mdiPencil, mdiTrashCan, mdiContentSave, mdiClose } from "@mdi/js";
import NotificationBar from '@/Components/NotificationBar.vue';
import BaseButton from '@/Components/BaseButton.vue';
import BaseButtons from '@/Components/BaseButtons.vue';
import { defineProps } from 'vue';
import { Link, Head, router } from "@inertiajs/vue3";
import JetInput from '@/Components/Input.vue';
import JetInputError from '@/Components/InputError.vue';
import JetButton from '@/Components/Button.vue';
import { useForm } from "@inertiajs/vue3";
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';

const props = defineProps({
    name: 'Edit',
    titulo: {
        type: String,
        required: true
    },
    routeName: {
        type: String,
        required: true
    },
    proyecto: { type: Object, required: true },
    subareas: { type: Array, required: true },
    areas: { type: Array, required: true },
    users: { type: Array, required: true },
    departamentos: { type: Array, required: true }
});

const form = useForm({ ...props.proyecto });

const filteredSubareas = computed(() => {
    if (!form.area_id) {
        return [];
    }
    return props.subareas.filter(subarea => subarea.area_id === form.area_id);
});

const guardar = () => {
    form.put(route("proyecto.update", props.proyecto.id));
};

const eliminar = () => {
    Swal.fire({
        title: "¿Está seguro?",
        text: "Esta acción no se puede revertir",
        icon: "warning",
        showCancelButton: true,
        cancelButtonText: "Cancelar",
        cancelButtonColor: "#d33",
        confirmButtonColor: "#3085d6",
        confirmButtonText: "¡Sí, eliminar registro!",
    }).then((res) => {
        if (res.isConfirmed) {
            form.delete(route("proyecto.destroy", props.proyecto.id));
        }
    });
};
</script>

<template>
<Head :title="titulo">
        <link rel="shortcut icon" type="image/png" href="/img/TecnmBlanco.png">
    </Head>
    <LayoutMain>
        <SectionTitleLineWithButton :icon="mdiPencil" :title="titulo" main>
            <a :href="route(`${routeName}index`)">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-x"
                    viewBox="0 0 16 16">
                    <path
                        d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                </svg>
            </a>
        </SectionTitleLineWithButton>
        <CardBox form @submit.prevent="guardar">
            <div class="space-y-6">
                <!-- Grid Container -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                    <!-- Nombre del Proyecto -->
                    <div class="mb-6">
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            <span class="text-red-600 mr-1">*</span>Nombre del Proyecto:
                        </label>
                        <input
                            id="name"
                            type="text"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 shadow-md"
                            v-model="form.name"
                            required
                            placeholder="Nombre del Proyecto"
                        />
                        <jet-input-error :message="form.errors.name" />
                    </div>

                    <!-- Palabra Clave del Proyecto -->
                    <div class="mb-6">
                        <label for="key_word" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            <span class="text-red-600 mr-1">*</span>Palabra Clave del Proyecto:
                        </label>
                        <input
                            id="key_word"
                            type="text"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 shadow-md"
                            v-model="form.key_word"
                            required
                            placeholder="Clave del Módulo"
                        />
                        <jet-input-error :message="form.errors.key_word" />
                    </div>

                    <!-- Descripción -->
                    <div class="mb-6">
                        <label for="description" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            <span class="text-red-600 mr-1">*</span>Descripción:
                        </label>
                        <textarea
                            id="description"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 shadow-md resize-none"
                            v-model="form.description"
                            required
                            placeholder="Descripción"
                            rows="4"
                        ></textarea>
                        <jet-input-error :message="form.errors.description" />
                    </div>

                    <!-- Objetivo del Proyecto -->
                    <div class="mb-6">
                        <label for="objective" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            <span class="text-red-600 mr-1">*</span>Objetivo del Proyecto:
                        </label>
                        <textarea
                            id="objective"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 shadow-md resize-none"
                            v-model="form.objective"
                            required
                            placeholder="Objetivo del Proyecto"
                            rows="4"
                        ></textarea>
                        <jet-input-error :message="form.errors.objective" />
                    </div>

                    <!-- Nombre del Área -->
                    <div class="mb-6">
                        <label for="area_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            <span class="text-red-600 mr-1">*</span>Nombre del Área
                        </label>
                        <select
                            id="area_id"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 shadow-md"
                            v-model="form.area_id"
                        >
                            <option value="">Seleccione una opción</option>
                            <option v-for="item in props.areas" :value="item.id" :key="item.id">
                                {{ item.name }}
                            </option>
                        </select>
                        <jet-input-error :message="form.errors.area_id" />
                    </div>

                    <!-- Nombre del SubÁrea -->
                    <div class="mb-6">
                        <label for="subarea_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            <span class="text-red-600 mr-1">*</span>Nombre del SubÁrea
                        </label>
                        <select
                            id="subarea_id"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 shadow-md"
                            v-model="form.subarea_id"
                        >
                            <option value="">Seleccione una opción</option>
                            <option v-for="item in filteredSubareas" :value="item.id" :key="item.id">
                                {{ item.name }}
                            </option>
                        </select>
                        <jet-input-error :message="form.errors.subarea_id" />
                    </div>

                    <!-- Nombre del Departamento -->
                    <div class="mb-6">
                        <label for="departamento_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            <span class="text-red-600 mr-1">*</span>Nombre del Departamento
                        </label>
                        <select
                            id="departamento_id"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 shadow-md"
                            v-model="form.departamento_id"
                        >
                            <option value="">Seleccione una opción</option>
                            <option v-for="item in departamentos" :value="item.id" :key="item.id">
                                {{ item.name }}
                            </option>
                        </select>
                        <jet-input-error :message="form.errors.departamento_id" />
                    </div>

                

                </div>
            </div>
            <template #footer>
                <BaseButtons>
                    <BaseButton :href="route(`${routeName}index`)" color="" label="Cancelar" />
                    <BaseButton @click="guardar" :icon="mdiContentSave" type="submit" color="info" label="Guardar" />
                    <BaseButton color="danger" :icon="mdiTrashCan" @click="eliminar" label="Eliminar" />
                </BaseButtons>
            </template>
        </CardBox>
    </LayoutMain>
</template>
