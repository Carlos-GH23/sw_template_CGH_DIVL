import {
  mdiAccountCircle,
  mdiMonitor,
  mdiGithub,
  mdiLock,
  mdiAlertCircle,
  mdiSquareEditOutline,
  mdiTable,
  mdiViewList,
  mdiTelevisionGuide,
  mdiResponsive,
  mdiPalette,
  mdiReact,
  mdiPlus,
  mdiAccountEdit,
  mdiDeleteEmpty,
  mdiAccountTie,
  mdiChartLine,
  mdiFileChartOutline,
  mdiAccountSchool,
    mdiMinus,
    mdiViewModule,
    mdiLockCheckOutline,
    mdiLockOutline,
    mdiAccountSupervisor,
    mdiAccount,
    mdiSchool,
    mdiTree,
    mdiLightbulbOutline,
    mdiRocket,
    mdiLightbulbOnOutline,
    mdiBook,
    mdiTheater,
    mdiOfficeBuilding,
    mdiDomain,
    mdiFileDocument,
    mdiHandshake,
    mdiCalendarMonth,
    mdiCrowd,
    mdiHumanMaleBoard,
    mdiPageLayoutHeader,
} from "@mdi/js";

export default [
  
  {
    href: "/dashboard",
    icon: mdiMonitor,
    label: "Inicio",
  },
  /* {
    href: "/tables",
    label: "Tables",
    icon: mdiTable,
  },
  {
    href: "/forms",
    label: "Forms",
    icon: mdiSquareEditOutline,
  },
  {
    href: "/ui",
    label: "UI",
    icon: mdiTelevisionGuide,
  },
  {
    href: "/responsive",
    label: "Responsive",
    icon: mdiResponsive,
  },
  {
    href: "/",
    label: "Styles",
    icon: mdiPalette,
  }, */
  {
    href: "/profile",
    label: "Perfil",
    icon: mdiAccountCircle,
  },
  {
    href: '/modulo',
    label: 'Graficas',
    icon: mdiChartLine,
  },
  {
    href: '/modulo',
    label: 'Reportes',
    icon: mdiFileChartOutline,
  },
/*   {
    href: "/login",
    label: "Login",
    icon: mdiLock,
  },
  {
    href: "/error",
    label: "Error",
    icon: mdiAlertCircle,
  },
  {
    label: "Dropdown",
    icon: mdiViewList,
    menu: [
      {
        label: "Item One",
      },
      {
        label: "Item Two",
      },
    ],
  },
  {
    href: "https://github.com/justboil/admin-one-vue-tailwind",
    label: "GitHub",
    icon: mdiGithub,
    target: "_blank",
  },
  {
    href: "https://github.com/justboil/admin-one-react-tailwind",
    label: "React version",
    icon: mdiReact,
    target: "_blank",
  }, */
  {
    label: "Seguridad",
    icon: mdiViewList,
    // role: "Admin",
    permission: "modulo.seguridad",
    menu: [
        {
            label: "Modulos",
            href: "/modulo",
            icon: mdiViewModule,
            permission: "modulo.index",
        },
        {
            label: "Permisos",
            href: "/permissions",
            icon: mdiLockCheckOutline,
            permission: "permissions.index",
        },
        {
            label: "Roles",
            href: "/perfiles",
            icon: mdiAccountSupervisor,
            permission: "perfiles.index",
        },
        {
            label: "Usuarios",
            href: "/usuarios",
            icon: mdiAccount,
            permission: "usuarios.index",
        },
        {
          label: "Secciones",
          href: "/seccion",
          icon: mdiPageLayoutHeader,
          permission: 'seccion.index',
        },
    ],
},
    {
      label: 'Gestión Usuarios',
      icon: mdiAccount,
      permission: 'modulo.seguridad',
      menu:[
        {
          label: "Profesores",
          href: "/seccion",
          icon: mdiAccountTie,
          permission: 'modulo.index'
        },
        {
          label: "Revsior",
          href: "/modulo",
          icon: mdiAccount,
          permission: 'modulo.index'
        },
        {
          label: "Estudiantes",
          href: '/modulo',
          icon: mdiAccountSchool,
          permission: 'modulo.index'
        },
      ]
    },
    /* {
      label: 'Revisor',
      icon: mdiAccountTie,
      permission: 'modulo.seguridad',
      menu:[
        {
          label: 'Crear Revisor',
          href: '/modulo',
          icon: mdiPlus,
          permission: 'modulo.index'
        },
        {
          label: 'Editar Revisor',
          href: '/modulo',
          icon: mdiAccountEdit,
          permission: 'modulo.index'
        },
        {
          label: 'Eliminar Revisor',
          href:'/modulo',
          icon: mdiDeleteEmpty,
          permission: 'modulo.index'
        }
      ]
    } */
];
