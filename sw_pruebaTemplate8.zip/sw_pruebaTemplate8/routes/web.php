<?php

use App\Http\Controllers\AreaController;
use App\Http\Controllers\CiudadController;
use App\Http\Controllers\ColoniaController;
use App\Http\Controllers\DepartamentoController;
use App\Http\Controllers\EstadoController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\InstitutionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ModuloController;
use App\Http\Controllers\MunicipioController;
use App\Http\Controllers\PerfilesController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\ProyectoController;
use App\Http\Controllers\RenapoController;
use App\Http\Controllers\SectionController;
use App\Http\Controllers\SubareaController;
use App\Http\Controllers\TipoEstanciaController;
use App\Http\Controllers\UsuarioController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::resource('renapo', RenapoController::class)->names('renapo');


/* Route::get('/dashboard', function () {
    //return Inertia::render('Dashboard');
	return Inertia::render('HomeView');
})->middleware(['auth', 'verified'])->name('dashboard'); */

//RUTA DE INICIO
Route::get('/dashboard', [HomeController::class, 'index']) ->middleware(['auth'])->name('dashboard');

Route::middleware(['auth'])->group(function () {
    //Rutas de seguridad
    Route::resource('modulo', ModuloController::class)->parameters(['modulo' => 'modulo']);
    Route::resource('permissions', PermissionController::class)->names('permissions');
    Route::resource('perfiles', PerfilesController::class)->parameters(['perfiles' => 'perfiles']);
    Route::resource('usuarios', UsuarioController::class)->parameters(['usuarios' => 'usuarios']);
    Route::resource('seccion', SectionController::class)->parameters(['seccion' => 'seccion']);
    //Rutas da Catalogos
    Route::resource('institucion', InstitutionController::class)->parameters(['institucion' => 'institucion']);
    Route::resource('tipo_estancia', TipoEstanciaController::class)->parameters(['tipo_estancia' => 'tipo_estancia']);
    Route::resource('departamento', DepartamentoController::class)->parameters(['departamento' => 'departamento']);
    Route::resource('area', AreaController::class)->parameters(['area' => 'area']);
    Route::resource('subarea', SubareaController::class)->parameters(['subarea' => 'subarea']);
    Route::resource('municipio', MunicipioController::class)->parameters(['ciudad' => 'ciudad']);
    Route::resource('estado', EstadoController::class)->parameters(['estado' => 'estado']);
    Route::resource('colonia', ColoniaController::class)->parameters(['colonia' => 'colonia']);

    //Rutas para Proyectos Profesor
    Route::resource('proyecto', ProyectoController::class)->parameters(['proyecto' => 'proyecto']);
    
    //Rutas


    //recoveries
    /* Route::get('institucion/recover/{id}', [InstitutionController::class, 'recover'])->name('institucion.recover'); */
});



 Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
}); 

require __DIR__.'/auth.php';